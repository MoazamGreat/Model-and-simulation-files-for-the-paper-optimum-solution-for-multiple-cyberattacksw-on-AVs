import os, traci
here = os.path.dirname(os.path.abspath(__file__))
traci.start(["sumo-gui", "-c", os.path.join(here, "city.sumocfg"), "--delay", "60", "--start"])
tracked = False
while traci.simulation.getMinExpectedNumber() > 0:
    traci.simulationStep()
    if "ego" in traci.vehicle.getIDList():
        if not tracked:
            traci.gui.trackVehicle("View #0", "ego")
            traci.gui.setZoom("View #0", 900)
            tracked = True
        traci.vehicle.highlight("ego", (255, 0, 0, 255), size=10)
traci.close()
