# SUMO simulation: city traffic, attacks and attack mitigation

A simulated city (SUMO) in which five CAN-bus attacks (DoS, Replay, Fuzzy, Gear spoofing, RPM spoofing) hit the vehicles. The attacks follow the burst timelines of the real datasets. The Hybrid Lite model (DCNN_Lite, int8 TFLite, XGBoost) is deployed on every vehicle and can detect an attack and switch the vehicle into a safe mode.

## What is in this folder

| File | Purpose |
|---|---|
| `city.sumocfg` | SUMO configuration (1,500 s run) |
| `city_base.net.xml` | Road network: 12 x 10 grid, 427 one-way segments, 147 traffic lights, sidewalks and crossings |
| `vtypes.add.xml`, `buildings.add.xml` | Vehicle types, buildings |
| `*.trips.xml` (9 files), `ped.rou.xml` | Traffic: cars, SUVs, taxis, vans, buses, trucks, motorbikes, bicycles, ambulances, pedestrians |
| `ego.rou.xml` | The red driver (ego) car and its route |
| `run_normal.py` / `run_normal.bat` | Normal traffic, no attack |
| `Dos_attack.py`, `Fuzzy_attack.py`, `Gear_attack.py`, `RPM_attack.py`, `Replay_attack.py` | One attack each |
| `attack.py` | All five attacks at once, without the defence (the unprotected run) |
| `attack_defense.py` | All five attacks with the Hybrid Lite defence (the protected run) |
| `run_attack.bat`, `run_defense.bat` | Start the attack runs and the defence run |
| `*_timeline.json` | Attack burst timelines taken from the datasets |
| `Replay_dataset_30pct.csv` | Synthetic Replay dataset (last 30%) |
| `make_30pct.py` | Builds the other four `*_30pct.csv` files from the original datasets |
| `setup_tf_env.bat` | Makes a Python 3.12 environment (`C:\tf_env`) with TensorFlow and XGBoost |
| `step1_add_sidewalks.bat`, `step2_make_traffic.bat` | Optional: rebuild the sidewalks and the random traffic. Not needed to run |
| `results/` | `unprotected_all_attacks_log.csv` and `protected_defense_log.csv`, the event logs of the two runs |

## Requirements

- Windows (the `.bat` files). The Python scripts also run on Linux or macOS if you start them by hand.
- Eclipse SUMO 1.28.0 with `sumo-gui` on the PATH and the `SUMO_HOME` variable set.
- Python 3.12 with `traci` and `numpy` for the attack scripts: `pip install traci numpy`.
- For the defence: also `tensorflow` and `xgboost`. Run `setup_tf_env.bat` once (about 500 MB). It installs everything into `C:\tf_env`.

## Data

The attack scripts run from the included timelines. The defence needs the real CAN frames, so it needs the five `*_30pct.csv` files in this folder.

1. Download the Car-Hacking dataset of Song et al. (HCRL, Korea University). Check its terms of use. It is not redistributed here.
2. Run: `python make_30pct.py --raw-dir <folder with DoS_dataset.csv, Fuzzy_dataset.csv, gear_dataset.csv, RPM_dataset.csv>`
3. `Replay_dataset_30pct.csv` is already included.

## How to run

Open a command prompt in this folder.

| Run | Command | What it shows |
|---|---|---|
| Normal traffic | `run_normal.bat` | The city without attacks. The red car is the driver car |
| One attack | `run_attack.bat dos` (or `fuzzy`, `gear`, `rpm`, `replay`) | Normal traffic for 60 s, an incident for the driver car, then that attack on the whole city |
| All five attacks, no defence | `run_attack.bat` | The unprotected run |
| All five attacks, with the defence | `run_defense.bat` | The protected run. The model is deployed at t = 60 s |

Options for `run_defense.bat`:

- `--retrain` trains the model again.
- `--quick` is a smaller, faster training for slow computers.
- `--no-defense` runs the same attacks without the model.

The first protected run trains the model on the five datasets before it starts. This takes several minutes, and the model is saved in `defense_model/` for later runs. Set `SUMO_NOGUI=1` to run without the window.

## What the attacks do to a hit vehicle

| Attack | Effect | Colour |
|---|---|---|
| DoS | Controls frozen: keeps its speed, ignores red lights, cannot brake | Magenta |
| Replay | Follows its own speed from 5 to 20 s earlier | Orange |
| Fuzzy | Random speed every second and random lane changes | Cyan |
| Gear | Neutral (coasts to a stop) or runaway (accelerates) | Yellow / lime |
| RPM | Limiter (forced to crawl) or surge (hunting speed) | Blue / white |

These are behavioural models of how an attack changes driving, not CAN physics. A vehicle is under one attack at a time.

## How the defence works

1. Once per second each vehicle's gateway classifies one 29 x 29 frame of CAN-ID bits. A vehicle under attack receives a real attack window from its dataset. Other vehicles receive real normal windows.
2. If the model flags the frame, an alarm is raised.
3. One second later the vehicle enters safe mode (dark green). Attack commands are rejected and normal driving is restored.
4. Safe mode lasts until 8 s after the last alarm. Nothing but the model's alarm can start it.

The simulation writes its event log to `defense_log.csv`, or `attack_log.csv` and `all_attacks_log.csv` for the attack runs. These are overwritten on each run.

## Notes

- The two files in `results/` are the event logs of one reference run each (unprotected and protected). A new run can differ slightly, because training gives slightly different model weights.
