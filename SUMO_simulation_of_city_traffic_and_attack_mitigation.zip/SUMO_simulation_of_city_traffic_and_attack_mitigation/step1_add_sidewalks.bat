@echo off
cd /d "%~dp0"
if "%SUMO_HOME%"=="" (echo SUMO_HOME is not set & pause & exit /b 1)
if not exist city_base.net.xml (echo city_base.net.xml not found in this folder & pause & exit /b 1)
if not exist city_base_backup.net.xml copy city_base.net.xml city_base_backup.net.xml
netconvert -s city_base_backup.net.xml --sidewalks.guess --sidewalks.guess.max-speed 20 --crossings.guess --crossings.guess.speed-threshold 17 --walkingareas --no-turnarounds true -o city_base.net.xml
echo.
echo Step 1 finished. Check for errors above.
pause
