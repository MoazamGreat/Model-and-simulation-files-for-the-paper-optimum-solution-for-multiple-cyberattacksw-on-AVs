@echo off
rem All five attacks + the Hybrid Lite defence (detection and mitigation).
rem Uses the environment made by setup_tf_env.bat (C:\tf_env); falls back to the normal Python if it is missing.
rem Options are passed on:  run_defense.bat --retrain   |   --quick   |   --no-defense
cd /d "%~dp0"
if exist C:\tf_env\Scripts\python.exe (
    C:\tf_env\Scripts\python.exe attack_defense.py %*
) else (
    python attack_defense.py %*
)
pause
