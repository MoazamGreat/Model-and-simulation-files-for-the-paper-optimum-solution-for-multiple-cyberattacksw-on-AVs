@echo off
rem Normal traffic only (no attack, no defence). Opens sumo-gui and follows the red driver (ego) car.
cd /d "%~dp0"
python run_normal.py
pause
