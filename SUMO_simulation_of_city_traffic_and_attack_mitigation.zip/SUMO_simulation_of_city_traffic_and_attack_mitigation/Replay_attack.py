"""
Replay_attack.py  -  Replay attack scenario (driven by the real Replay CAN dataset)

Run:  python Replay_attack.py

A replay attack re-sends OLD, perfectly valid CAN messages. The ECU cannot tell they are
stale, so the vehicle acts on commands that belonged to an earlier moment: it keeps
"cruising" when it should stop, or stops dead on an open road when it should go.
Here this is modelled as: a hit vehicle follows its OWN speed from `lag` seconds ago
(a time-shifted copy of its past behaviour) for REPLAY_HOLD_S seconds.

What you will see
  1. NORMAL     : clean city traffic. A checkpoint is saved every 10 s.
  2. INCIDENT   : the first replay burst of the dataset hits the red "ego" car. It replays an
                  old "full speed" command and cannot react to what is ahead. A stopped car
                  (stalled in the ego lane) is placed on its path so the accident is certain.
  3. RELOAD     : the simulation jumps back to the last saved checkpoint.
  4. CITY_ATTACK: every replay burst of the dataset is mapped onto the whole city. A share of
                  the vehicles in each burst is hit (turns ORANGE) and replays stale speeds.

Files used (same folder as this script):
  city.sumocfg + network/route files        (unchanged)
  replay_timeline.json                      (attack timeline from the Replay dataset; rebuilt
                                             from Replay_dataset_30pct.csv if missing)
It writes:
  replay_attack_log.csv   every burst / victim / crash with its dataset second
  checkpoints_replay/     the saved states
"""
import os, csv, json, time, zlib
from bisect import bisect_left, bisect_right
from collections import deque
import traci

# ======================= SETTINGS (safe to change) =======================
ATTACK_START_S     = 60     # first replay burst at or after this sim time starts the incident
CHECKPOINT_EVERY_S = 10     # save a checkpoint every N sim seconds while traffic is clean
INCIDENT_TIMEOUT_S = 40     # if the ego has not crashed this long after the attack, reload anyway
EGO_MIN_SPEED      = 14.0   # m/s of the stale "cruise" command the ego replays
STALLED_CAR_AHEAD  = 90     # m: a stopped car ahead of the ego
SIM_END_S          = 1500   # same as <end> in city.sumocfg
CITY_INFECTION     = 0.15   # share of vehicles hit by an average burst (0.15 = 15 %)
REPLAY_HOLD_S      = 8      # how long a hit vehicle keeps replaying old commands
LAG_MIN_S, LAG_MAX_S = 5, 20   # how old the replayed command is (random per vehicle)
HIST_S             = 30     # seconds of speed history that are remembered
MAX_RELOADS        = 1      # how many times to reload a checkpoint after an ego crash
PAUSE_AFTER_CRASH  = 2.5    # real seconds to look at the wreck before reloading
USE_GUI            = os.environ.get("SUMO_NOGUI") is None   # SUMO_NOGUI=1 -> headless test
# ==========================================================================

HERE = os.path.dirname(os.path.abspath(__file__))
CFG = os.path.join(HERE, "city.sumocfg")
CKPT_DIR = os.path.join(HERE, "checkpoints_replay")
LOG_FILE = os.path.join(HERE, "replay_attack_log.csv")
TIMELINE_JSON = os.path.join(HERE, "replay_timeline.json")
REPLAY_CSV = os.path.join(HERE, "Replay_dataset_30pct.csv")

ATTACK_COLOR = (255, 140, 0, 255)   # orange = vehicle replaying old commands


# ----------------------- 1. dataset -> attack timeline -----------------------
def build_timeline_json():
    """Count, for every second of the dataset, all CAN messages and attack ('T') messages."""
    total, attack, t0 = {}, {}, None
    with open(REPLAY_CSV) as f:
        for line in f:
            p = line.strip().split(",")
            ts = float(p[0])
            if t0 is None:
                t0 = ts
            s = int(ts - t0)
            total[s] = total.get(s, 0) + 1
            if p[-1] == "T":
                attack[s] = attack.get(s, 0) + 1
    n = max(total) + 1
    data = {"total": [total.get(i, 0) for i in range(n)],
            "attack": [attack.get(i, 0) for i in range(n)]}
    with open(TIMELINE_JSON, "w") as f:
        json.dump(data, f)
    return data


class Timeline:
    """Attack 'windows' = runs of consecutive dataset seconds that contain replayed frames."""
    def __init__(self):
        if not os.path.exists(TIMELINE_JSON):
            print("replay_timeline.json not found -> building it from", REPLAY_CSV)
            data = build_timeline_json()
        else:
            with open(TIMELINE_JSON) as f:
                data = json.load(f)
        self.total, self.attack = data["total"], data["attack"]
        n = len(self.total)
        self.win_of = [-1] * n
        self.windows = []
        cur = None
        for i in range(n):
            if self.attack[i] > 0:
                if cur is None:
                    cur = {"start": i, "end": i, "atk": 0, "tot": 0}
                    self.windows.append(cur)
                cur["end"] = i
                cur["atk"] += self.attack[i]
                cur["tot"] += self.total[i]
                self.win_of[i] = len(self.windows) - 1
            else:
                cur = None
        for w in self.windows:
            w["ratio"] = w["atk"] / max(1, w["tot"])
        self.starts = [w["start"] for w in self.windows]
        self.mean_ratio = sum(w["ratio"] for w in self.windows) / len(self.windows)

    def window_at(self, sec):
        return self.win_of[sec] if 0 <= sec < len(self.win_of) else -1

    def active_windows(self, sec):
        """Bursts whose replayed commands are still in effect at this second."""
        lo = bisect_left(self.starts, sec - REPLAY_HOLD_S + 1)
        hi = bisect_right(self.starts, sec)
        return range(lo, hi)

    def hit_probability(self, wid):
        """Stronger bursts (more replayed frames) hit more vehicles."""
        return min(1.0, CITY_INFECTION * self.windows[wid]["ratio"] / self.mean_ratio)


def dice(veh_id, wid, salt=""):
    """Deterministic 'random' number in [0,1): same vehicle + burst -> same answer."""
    return zlib.crc32(("%s:%d:%s" % (veh_id, wid, salt)).encode()) / 2**32


# ----------------------- 2. helpers -----------------------
class Log:
    def __init__(self):
        self.f = open(LOG_FILE, "w", newline="")
        self.w = csv.writer(self.f)
        self.w.writerow(["sim_time", "scenario", "event", "vehicle", "window_id",
                         "dataset_second", "attack_ratio", "detail"])

    def add(self, t, scenario, event, veh="", wid="", sec="", ratio="", detail=""):
        self.w.writerow([round(t, 1), scenario, event, veh, wid, sec,
                         ratio if ratio == "" else round(ratio, 3), detail])
        self.f.flush()


def banner(text):
    print("\n" + "=" * 70 + "\n  " + text + "\n" + "=" * 70, flush=True)


def restore(veh, color=None):
    try:
        traci.vehicle.setSpeedMode(veh, 31)
        traci.vehicle.setLaneChangeMode(veh, 1621)
        traci.vehicle.setSpeed(veh, -1)
        if color is not None:
            traci.vehicle.setColor(veh, color)
    except traci.TraCIException:
        pass


def stale_speed(hist, lag, current):
    """The speed this vehicle had `lag` seconds ago (= the replayed old command)."""
    if not hist:
        return current
    return hist[-lag] if len(hist) >= lag else hist[0]


def place_stalled_car(ego="ego"):
    """Put a stopped car in the ego's lane ahead of it. Returns True once placed."""
    edge = traci.vehicle.getRoadID(ego)
    if edge.startswith(":"):
        return False
    pos = traci.vehicle.getLanePosition(ego)
    length = traci.lane.getLength(traci.vehicle.getLaneID(ego))
    if length - pos < 50:
        return False
    at = min(pos + STALLED_CAR_AHEAD, length - 8)
    try:
        traci.route.add("obstacle_route", [edge])
        traci.vehicle.add("obstacle", "obstacle_route", typeID="car", depart="now",
                          departLane=str(traci.vehicle.getLaneIndex(ego)),
                          departPos=str(at), departSpeed="0")
        traci.vehicle.setSpeedMode("obstacle", 0)
        traci.vehicle.setSpeed("obstacle", 0)
        traci.vehicle.setColor("obstacle", (120, 120, 120, 255))
    except traci.TraCIException:
        return False
    return True


# ----------------------- 3. main simulation -----------------------
def main():
    tl = Timeline()
    log = Log()
    os.makedirs(CKPT_DIR, exist_ok=True)

    cmd = ["sumo-gui" if USE_GUI else "sumo", "-c", CFG,
           "--collision.check-junctions", "true",
           "--collision.action", "warn",
           "--collision.stoptime", "8",
           "--no-step-log", "true"]
    if USE_GUI:
        cmd += ["--delay", "60", "--start"]
    traci.start(cmd)

    scenario = "NORMAL"
    tracked = False
    last_ckpt, last_ckpt_sec, ckpt_hist = None, -1, {}
    incident_t0 = crash_t = None
    reloads = 0
    obstacle_placed = False
    hist = {}            # vehicle -> recent natural speeds (the "recorded commands")
    held = {}            # vehicle -> {"wid", "lag", "until"} while replaying old commands
    orig_color = {}
    seen_collisions = set()
    stats = {"victims": set(), "collisions": 0, "windows": set()}

    banner("SCENARIO 1/3  NORMAL traffic (checkpoints every %d s)" % CHECKPOINT_EVERY_S)

    while traci.simulation.getMinExpectedNumber() > 0:
        traci.simulationStep()
        t = traci.simulation.getTime()
        if t >= SIM_END_S:
            break
        sec = int(t)
        ids = traci.vehicle.getIDList()
        ego_here = "ego" in ids

        # --- record each vehicle's natural speed (what could be replayed later) ---
        for v in ids:
            if v in held or (v == "ego" and scenario == "INCIDENT"):
                continue
            h = hist.get(v)
            if h is None:
                h = hist[v] = deque(maxlen=HIST_S)
            h.append(traci.vehicle.getSpeed(v))
        for v in [v for v in hist if v not in ids]:
            del hist[v]

        # --- ego camera + highlight ---
        if ego_here:
            if not tracked:
                if USE_GUI:
                    traci.gui.trackVehicle("View #0", "ego")
                    traci.gui.setZoom("View #0", 900)
                tracked = True
            traci.vehicle.highlight("ego", (255, 0, 0, 255), size=10)

        # --- collisions this step ---
        ego_hit = False
        for c in traci.simulation.getCollisions():
            key = (scenario, c.collider, c.victim)
            if key in seen_collisions:
                continue
            seen_collisions.add(key)
            stats["collisions"] += 1
            if "ego" in (c.collider, c.victim):
                ego_hit = True
            log.add(t, scenario, "COLLISION", c.collider, tl.window_at(sec), sec,
                    detail="victim=%s edge=%s" % (c.victim, c.lane.rsplit("_", 1)[0]))

        # ================= scenario logic =================
        if scenario == "NORMAL":
            if sec % CHECKPOINT_EVERY_S == 0 and sec != last_ckpt_sec:
                last_ckpt = os.path.join(CKPT_DIR, "ckpt_%04d.xml" % sec)
                traci.simulation.saveState(last_ckpt)
                last_ckpt_sec = sec
                ckpt_hist = {v: list(d) for v, d in hist.items()}
                log.add(t, scenario, "CHECKPOINT", detail=os.path.basename(last_ckpt))
            wid = tl.window_at(sec)
            if t >= ATTACK_START_S and wid >= 0:
                scenario, incident_t0 = "INCIDENT", t
                w = tl.windows[wid]
                banner("SCENARIO 2/3  REPLAY ATTACK on the driver (t=%.0f s, dataset burst #%d, "
                       "%.0f%% replayed frames)" % (t, wid, 100 * w["ratio"]))
                log.add(t, scenario, "ATTACK_START", "ego", wid, sec, w["ratio"],
                        "last checkpoint=%s" % os.path.basename(last_ckpt))
                if ego_here:
                    orig_color["ego"] = traci.vehicle.getColor("ego")

        elif scenario == "INCIDENT":
            if ego_here:
                # the ego replays an old "full speed" command and ignores everything around it
                old_cruise = max(hist.get("ego", [0]) or [0])
                traci.vehicle.setSpeedMode("ego", 0)
                traci.vehicle.setLaneChangeMode("ego", 0)
                traci.vehicle.setSpeed("ego", max(EGO_MIN_SPEED, old_cruise))
                if not obstacle_placed:
                    obstacle_placed = place_stalled_car("ego")
                    if obstacle_placed:
                        log.add(t, scenario, "STALLED_CAR", "obstacle", detail="placed ahead of ego")
            if crash_t is None and ego_hit:
                crash_t = t
                banner("ACCIDENT! The ego car acted on a replayed command and crashed at t=%.0f s" % t)
                log.add(t, scenario, "EGO_CRASH", "ego", tl.window_at(sec), sec)
            elif crash_t is None and t - incident_t0 >= INCIDENT_TIMEOUT_S:
                crash_t = t
                banner("No crash within %d s - treating the loss of control as the incident"
                       % INCIDENT_TIMEOUT_S)
                log.add(t, scenario, "INCIDENT_TIMEOUT", "ego")
            if crash_t is not None and t >= crash_t + 3:
                if reloads >= MAX_RELOADS or last_ckpt is None:
                    scenario = "CITY_ATTACK"
                else:
                    if USE_GUI:
                        time.sleep(PAUSE_AFTER_CRASH)
                    banner("RELOAD  back to checkpoint %s (sim time %d s)" %
                           (os.path.basename(last_ckpt), last_ckpt_sec))
                    traci.simulation.loadState(last_ckpt)
                    reloads += 1
                    restore("ego", orig_color.get("ego"))
                    held.clear()
                    hist = {v: deque(l, maxlen=HIST_S) for v, l in ckpt_hist.items()}
                    tracked = False
                    scenario = "CITY_ATTACK"
                    log.add(traci.simulation.getTime(), scenario, "RELOAD", "",
                            detail=os.path.basename(last_ckpt))
                    banner("SCENARIO 3/3  CITY-WIDE REPLAY attack (every dataset burst, "
                           "~%d%% of vehicles per burst)" % int(CITY_INFECTION * 100))
                    continue

        elif scenario == "CITY_ATTACK":
            actives = tl.active_windows(sec) if t >= ATTACK_START_S else []
            for wid in actives:
                if wid not in stats["windows"]:
                    stats["windows"].add(wid)
                    log.add(t, scenario, "WINDOW_START", "", wid, sec, tl.windows[wid]["ratio"],
                            "p_hit=%.2f" % tl.hit_probability(wid))
            # 1) which vehicles are hit by a (still active) burst?
            for v in ids:
                for wid in actives:
                    if dice(v, wid) < tl.hit_probability(wid):
                        until = tl.windows[wid]["start"] + REPLAY_HOLD_S
                        info = held.get(v)
                        if info is None:
                            lag = LAG_MIN_S + int(dice(v, wid, "lag") * (LAG_MAX_S - LAG_MIN_S + 1))
                            held[v] = {"wid": wid, "lag": lag, "until": until}
                            orig_color[v] = traci.vehicle.getColor(v)
                            traci.vehicle.setSpeedMode(v, 0)
                            traci.vehicle.setColor(v, ATTACK_COLOR)
                            stats["victims"].add(v)
                            old = stale_speed(hist.get(v), lag, traci.vehicle.getSpeed(v))
                            log.add(t, scenario, "VICTIM", v, wid, sec, tl.windows[wid]["ratio"],
                                    "lag=%ds stale_speed=%.1f edge=%s" %
                                    (lag, old, traci.vehicle.getRoadID(v)))
                        else:
                            info["until"] = max(info["until"], until)
            # 2) hit vehicles replay old speeds; others recover when the burst is over
            for v in list(held):
                if v not in ids:
                    held.pop(v)
                elif sec >= held[v]["until"]:
                    restore(v, orig_color.get(v))
                    held.pop(v)
                    log.add(t, scenario, "RECOVER", v, "", sec)
                else:
                    traci.vehicle.setSpeed(
                        v, stale_speed(hist.get(v), held[v]["lag"], traci.vehicle.getSpeed(v)))

    log.add(traci.simulation.getTime(), scenario, "END", detail=(
        "windows=%d victims=%d collisions=%d" %
        (len(stats["windows"]), len(stats["victims"]), stats["collisions"])))
    banner("DONE  replay bursts: %d | vehicles hit: %d | collisions: %d\n"
           "  Log written to replay_attack_log.csv" %
           (len(stats["windows"]), len(stats["victims"]), stats["collisions"]))
    traci.close()


if __name__ == "__main__":
    main()
