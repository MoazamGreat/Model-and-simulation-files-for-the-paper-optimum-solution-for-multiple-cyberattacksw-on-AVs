@echo off
rem Attacks WITHOUT the defence.
rem   run_attack.bat            -> all five attacks at once (attack.py)
rem   run_attack.bat dos        -> DoS only      (also: fuzzy, gear, rpm, replay)
cd /d "%~dp0"
if "%1"=="" (python attack.py & goto :end)
if /i "%1"=="dos"    (python Dos_attack.py    & goto :end)
if /i "%1"=="fuzzy"  (python Fuzzy_attack.py  & goto :end)
if /i "%1"=="gear"   (python Gear_attack.py   & goto :end)
if /i "%1"=="rpm"    (python RPM_attack.py    & goto :end)
if /i "%1"=="replay" (python Replay_attack.py & goto :end)
echo Unknown attack "%1". Use dos, fuzzy, gear, rpm or replay.
:end
pause
