"""
Gear_attack.py  -  Gear-spoofing attack scenario (driven by the real Gear CAN dataset)

Run:  python Gear_attack.py

A gear-spoofing attack injects a fake "gear position" message (always the same CAN ID and
payload). The drivetrain and the dashboard believe the car is in a gear it is not in.
Here this is modelled with the two worst cases of a spoofed gear value:
  NEUTRAL  (yellow) : the car thinks it is in neutral -> no drive torque, it coasts down
                      and stalls in the middle of the road, even on a green light.
  RUNAWAY  (lime)   : the car is forced into a wrong gear -> unintended acceleration; it
                      speeds up and cannot brake for red lights or the car ahead.
Each hit vehicle gets one of the two (about half and half).

What you will see
  1. NORMAL     : clean city traffic. A checkpoint is saved every 10 s.
  2. INCIDENT   : the first gear-spoofing burst of the dataset hits the red "ego" car. It
                  accelerates uncontrollably. A stopped car (stalled in the ego lane) is
                  placed on its path so the accident is certain.
  3. RELOAD     : the simulation jumps back to the last saved checkpoint.
  4. CITY_ATTACK: every gear-spoofing burst of the dataset is mapped onto the whole city. A
                  share of the vehicles in each burst is hit and stalls or runs away.

Files used (same folder as this script):
  city.sumocfg + network/route files        (unchanged)
  gear_timeline.json                        (attack timeline from the Gear dataset; rebuilt
                                             from gear_dataset_30pct.csv if missing)
It writes:
  gear_attack_log.csv   every burst / victim / crash with its dataset second
  checkpoints_gear/     the saved states
"""
import os, sys, csv, json, time, zlib
import traci

# ======================= SETTINGS (safe to change) =======================
ATTACK_START_S     = 60     # first gear-spoofing burst at or after this sim time starts the incident
CHECKPOINT_EVERY_S = 10     # save a checkpoint every N sim seconds while traffic is clean
INCIDENT_TIMEOUT_S = 40     # if the ego has not crashed this long after the attack, reload anyway
NEUTRAL_SHARE      = 0.5    # share of hit vehicles whose gear is spoofed to NEUTRAL (rest: RUNAWAY)
COAST_DECAY        = 0.85   # NEUTRAL: speed is multiplied by this every second (coasting down)
RUNAWAY_ACCEL      = 2.5    # RUNAWAY: m/s gained every second
RUNAWAY_MAX_SPEED  = 18.0   # RUNAWAY: top speed in m/s
STALLED_CAR_AHEAD  = 90     # m: a stopped car (e.g. queue at a red light) ahead of the ego
SIM_END_S          = 1500   # same as <end> in city.sumocfg
CITY_INFECTION     = 0.20   # share of vehicles hit in an average attack burst (0.20 = 20 %)
MAX_RELOADS        = 1      # how many times to reload a checkpoint after an ego crash
PAUSE_AFTER_CRASH  = 2.5    # real seconds to look at the wreck before reloading
USE_GUI            = os.environ.get("SUMO_NOGUI") is None   # set SUMO_NOGUI=1 for a headless test
# ==========================================================================

HERE = os.path.dirname(os.path.abspath(__file__))
CFG = os.path.join(HERE, "city.sumocfg")
CKPT_DIR = os.path.join(HERE, "checkpoints_gear")
LOG_FILE = os.path.join(HERE, "gear_attack_log.csv")
TIMELINE_JSON = os.path.join(HERE, "gear_timeline.json")
GEAR_CSV = os.path.join(HERE, "gear_dataset_30pct.csv")

NEUTRAL_COLOR = (255, 230, 0, 255)   # yellow = gear spoofed to neutral (coasting)
RUNAWAY_COLOR = (0, 255, 60, 255)    # lime   = wrong gear, unintended acceleration


# ----------------------- 1. dataset -> attack timeline -----------------------
def build_timeline_json():
    """Count, for every second of the dataset, all CAN messages and attack ('T') messages."""
    total, attack, t0 = {}, {}, None
    with open(GEAR_CSV) as f:
        for line in f:
            p = line.strip().split(",")
            ts = float(p[0])
            if t0 is None:
                t0 = ts
            s = int(ts - t0)
            total[s] = total.get(s, 0) + 1
            if p[-1] == "T":
                attack[s] = attack.get(s, 0) + 1
    n = max(total) + 1
    data = {"total": [total.get(i, 0) for i in range(n)],
            "attack": [attack.get(i, 0) for i in range(n)]}
    with open(TIMELINE_JSON, "w") as f:
        json.dump(data, f)
    return data


class Timeline:
    """Attack 'windows' = runs of consecutive dataset seconds that contain attack messages."""
    def __init__(self):
        if not os.path.exists(TIMELINE_JSON):
            print("gear_timeline.json not found -> building it from", GEAR_CSV)
            data = build_timeline_json()
        else:
            with open(TIMELINE_JSON) as f:
                data = json.load(f)
        self.total, self.attack = data["total"], data["attack"]
        n = len(self.total)
        self.win_of = [-1] * n
        self.windows = []
        cur = None
        for i in range(n):
            if self.attack[i] > 0:
                if cur is None:
                    cur = {"start": i, "end": i, "atk": 0, "tot": 0}
                    self.windows.append(cur)
                cur["end"] = i
                cur["atk"] += self.attack[i]
                cur["tot"] += self.total[i]
                self.win_of[i] = len(self.windows) - 1
            else:
                cur = None
        for w in self.windows:
            w["ratio"] = w["atk"] / max(1, w["tot"])
        self.mean_ratio = sum(w["ratio"] for w in self.windows) / len(self.windows)

    def window_at(self, sec):
        return self.win_of[sec] if 0 <= sec < len(self.win_of) else -1

    def hit_probability(self, wid):
        """Stronger bursts (higher share of attack frames) hit more vehicles."""
        return min(1.0, CITY_INFECTION * self.windows[wid]["ratio"] / self.mean_ratio)


def is_victim(veh_id, wid, p):
    """Deterministic 'dice': same vehicle + same burst always gives the same answer."""
    return (zlib.crc32(("%s:%d" % (veh_id, wid)).encode()) / 2**32) < p


# ----------------------- 2. helpers -----------------------
class Log:
    def __init__(self):
        self.f = open(LOG_FILE, "w", newline="")
        self.w = csv.writer(self.f)
        self.w.writerow(["sim_time", "scenario", "event", "vehicle", "window_id",
                         "dataset_second", "attack_ratio", "detail"])

    def add(self, t, scenario, event, veh="", wid="", sec="", ratio="", detail=""):
        self.w.writerow([round(t, 1), scenario, event, veh, wid, sec,
                         ratio if ratio == "" else round(ratio, 3), detail])
        self.f.flush()


def banner(text):
    print("\n" + "=" * 70 + "\n  " + text + "\n" + "=" * 70, flush=True)


def compromise(veh):
    """Spoofed gear: the vehicle no longer follows the normal driving logic -> no safe braking,
    no lane changes, ignores red lights and right of way."""
    try:
        traci.vehicle.setSpeedMode(veh, 0)
        traci.vehicle.setLaneChangeMode(veh, 0)
    except traci.TraCIException:
        pass


def gear_mode(veh, wid):
    """Which wrong gear the spoofed message puts this vehicle in (fixed per vehicle + burst)."""
    r = zlib.crc32(("%s:%d:gear" % (veh, wid)).encode()) / 2**32
    return "NEUTRAL" if r < NEUTRAL_SHARE else "RUNAWAY"


def runaway_speed(current):
    return min(RUNAWAY_MAX_SPEED, current + RUNAWAY_ACCEL)


def gear_speed(mode, current):
    """Speed the vehicle is forced to follow this second."""
    if mode == "NEUTRAL":
        v = current * COAST_DECAY
        return 0.0 if v < 0.3 else v
    return runaway_speed(current)


def restore(veh, color=None):
    try:
        traci.vehicle.setSpeedMode(veh, 31)
        traci.vehicle.setLaneChangeMode(veh, 1621)
        traci.vehicle.setSpeed(veh, -1)
        if color is not None:
            traci.vehicle.setColor(veh, color)
    except traci.TraCIException:
        pass


def place_stalled_car(ego="ego"):
    """Put a stopped car in the ego's lane ahead of it (like a queue at a red light).
    Returns True once it has been placed."""
    edge = traci.vehicle.getRoadID(ego)
    if edge.startswith(":"):                       # ego is inside a junction: try next step
        return False
    pos = traci.vehicle.getLanePosition(ego)
    length = traci.lane.getLength(traci.vehicle.getLaneID(ego))
    if length - pos < 50:                          # too close to the end of the edge
        return False
    at = min(pos + STALLED_CAR_AHEAD, length - 8)
    try:
        traci.route.add("obstacle_route", [edge])
        traci.vehicle.add("obstacle", "obstacle_route", typeID="car", depart="now",
                          departLane=str(traci.vehicle.getLaneIndex(ego)),
                          departPos=str(at), departSpeed="0")
        traci.vehicle.setSpeedMode("obstacle", 0)
        traci.vehicle.setSpeed("obstacle", 0)
        traci.vehicle.setColor("obstacle", (120, 120, 120, 255))
    except traci.TraCIException:
        return False
    return True


# ----------------------- 3. main simulation -----------------------
def main():
    tl = Timeline()
    log = Log()
    os.makedirs(CKPT_DIR, exist_ok=True)

    cmd = ["sumo-gui" if USE_GUI else "sumo", "-c", CFG,
           "--collision.check-junctions", "true",   # also detect crashes inside junctions
           "--collision.action", "warn",
           "--collision.stoptime", "8",             # crashed cars stay put for 8 s
           "--no-step-log", "true"]
    if USE_GUI:
        cmd += ["--delay", "60", "--start"]
    traci.start(cmd)

    scenario = "NORMAL"
    tracked = False
    last_ckpt, last_ckpt_sec = None, -1
    incident_t0 = crash_t = None
    reloads = 0
    modes = {}           # vehicle -> "NEUTRAL" or "RUNAWAY"
    held = {}            # vehicles currently under attack (value = speed when hit)
    orig_color = {}      # vehicle -> its normal colour
    seen_collisions = set()
    stats = {"victims": set(), "collisions": 0, "windows": set()}

    banner("SCENARIO 1/3  NORMAL traffic (checkpoints every %d s)" % CHECKPOINT_EVERY_S)

    obstacle_placed = False
    while traci.simulation.getMinExpectedNumber() > 0:
        traci.simulationStep()
        t = traci.simulation.getTime()
        if t >= SIM_END_S:
            break
        sec = int(t)
        ids = traci.vehicle.getIDList()
        ego_here = "ego" in ids

        # --- ego camera + highlight (same as before) ---
        if ego_here:
            if not tracked:
                if USE_GUI:
                    traci.gui.trackVehicle("View #0", "ego")
                    traci.gui.setZoom("View #0", 900)
                tracked = True
            traci.vehicle.highlight("ego", (255, 0, 0, 255), size=10)

        # --- collisions this step ---
        ego_hit = False
        for c in traci.simulation.getCollisions():
            key = (scenario, c.collider, c.victim)
            if key in seen_collisions:
                continue
            seen_collisions.add(key)
            stats["collisions"] += 1
            if "ego" in (c.collider, c.victim):
                ego_hit = True
            log.add(t, scenario, "COLLISION", c.collider, tl.window_at(sec), sec,
                    detail="victim=%s edge=%s" % (c.victim, c.lane.rsplit("_", 1)[0]))

        # ================= scenario logic =================
        if scenario == "NORMAL":
            if sec % CHECKPOINT_EVERY_S == 0 and sec != last_ckpt_sec:
                last_ckpt = os.path.join(CKPT_DIR, "ckpt_%04d.xml" % sec)
                traci.simulation.saveState(last_ckpt)
                last_ckpt_sec = sec
                log.add(t, scenario, "CHECKPOINT", detail=os.path.basename(last_ckpt))
            wid = tl.window_at(sec)
            if t >= ATTACK_START_S and wid >= 0:
                scenario, incident_t0 = "INCIDENT", t
                w = tl.windows[wid]
                banner("SCENARIO 2/3  GEAR-SPOOFING ATTACK on the driver (t=%.0f s, dataset burst #%d, "
                       "%.0f%% attack frames)" % (t, wid, 100 * w["ratio"]))
                log.add(t, scenario, "ATTACK_START", "ego", wid, sec, w["ratio"],
                        "last checkpoint=%s" % os.path.basename(last_ckpt))
                if ego_here:
                    orig_color["ego"] = traci.vehicle.getColor("ego")
                    compromise("ego")

        elif scenario == "INCIDENT":
            if ego_here:
                compromise("ego")
                traci.vehicle.setSpeed("ego", runaway_speed(traci.vehicle.getSpeed("ego")))
                if not obstacle_placed:
                    obstacle_placed = place_stalled_car("ego")
                    if obstacle_placed:
                        log.add(t, scenario, "STALLED_CAR", "obstacle", detail="placed ahead of ego")
            if crash_t is None and ego_hit:
                crash_t = t
                banner("ACCIDENT! The ego car (wrong gear, runaway acceleration) crashed at t=%.0f s" % t)
                log.add(t, scenario, "EGO_CRASH", "ego", tl.window_at(sec), sec)
            elif crash_t is None and t - incident_t0 >= INCIDENT_TIMEOUT_S:
                crash_t = t
                banner("No crash within %d s - treating the loss of control as the incident"
                       % INCIDENT_TIMEOUT_S)
                log.add(t, scenario, "INCIDENT_TIMEOUT", "ego")
            if crash_t is not None and t >= crash_t + 3:
                if reloads >= MAX_RELOADS or last_ckpt is None:
                    scenario = "CITY_ATTACK"
                else:
                    if USE_GUI:
                        time.sleep(PAUSE_AFTER_CRASH)
                    banner("RELOAD  back to checkpoint %s (sim time %d s)" %
                           (os.path.basename(last_ckpt), last_ckpt_sec))
                    traci.simulation.loadState(last_ckpt)
                    reloads += 1
                    restore("ego", orig_color.get("ego"))
                    held.clear()
                    modes.clear()
                    tracked = False
                    scenario = "CITY_ATTACK"
                    log.add(traci.simulation.getTime(), scenario, "RELOAD", "",
                            detail=os.path.basename(last_ckpt))
                    banner("SCENARIO 3/3  CITY-WIDE GEAR-SPOOFING attack (every dataset burst, "
                           "~%d%% of vehicles per burst)" % int(CITY_INFECTION * 100))
                    continue

        elif scenario == "CITY_ATTACK":
            wid = tl.window_at(sec) if t >= ATTACK_START_S else -1
            victims_now = set()
            if wid >= 0:
                p = tl.hit_probability(wid)
                victims_now = {v for v in ids if is_victim(v, wid, p)}
                if wid not in stats["windows"]:
                    stats["windows"].add(wid)
                    log.add(t, scenario, "WINDOW_START", "", wid, sec, tl.windows[wid]["ratio"],
                            "p_hit=%.2f" % p)
            for v in victims_now - set(held):                      # newly attacked
                held[v] = traci.vehicle.getSpeed(v)
                orig_color[v] = traci.vehicle.getColor(v)
                modes[v] = gear_mode(v, wid)
                compromise(v)
                traci.vehicle.setColor(v, NEUTRAL_COLOR if modes[v] == "NEUTRAL" else RUNAWAY_COLOR)
                stats["victims"].add(v)
                log.add(t, scenario, "VICTIM", v, wid, sec, tl.windows[wid]["ratio"],
                        "gear=%s edge=%s speed=%.1f" % (modes[v], traci.vehicle.getRoadID(v), held[v]))
            for v in list(held):
                if v not in ids:                                   # left the map
                    held.pop(v)
                elif v in victims_now:                             # still hit: wrong gear
                    traci.vehicle.setSpeed(v, gear_speed(modes[v], traci.vehicle.getSpeed(v)))
                else:                                              # burst over: recover
                    restore(v, orig_color.get(v))
                    held.pop(v)
                    log.add(t, scenario, "RECOVER", v, "", sec)

    log.add(traci.simulation.getTime(), scenario, "END", detail=(
        "windows=%d victims=%d collisions=%d" %
        (len(stats["windows"]), len(stats["victims"]), stats["collisions"])))
    banner("DONE  attack windows: %d | vehicles hit: %d | collisions: %d\n"
           "  Log written to gear_attack_log.csv" %
           (len(stats["windows"]), len(stats["victims"]), stats["collisions"]))
    traci.close()


if __name__ == "__main__":
    main()
