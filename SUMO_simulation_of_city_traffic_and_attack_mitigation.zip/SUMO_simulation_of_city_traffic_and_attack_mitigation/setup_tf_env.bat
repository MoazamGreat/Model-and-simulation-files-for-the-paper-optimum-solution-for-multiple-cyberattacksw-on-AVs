@echo off
title Install TensorFlow + XGBoost for the SUMO simulation
echo ============================================================
echo  This makes a separate Python 3.12 environment in C:\tf_env
echo  (your Python 3.15 is NOT touched). It downloads about 500 MB.
echo ============================================================
echo.

echo [1/4] Looking for Python 3.12 ...
py -3.12 --version >nul 2>&1
if errorlevel 1 (
    echo Python 3.12 not found. Installing it with winget ...
    winget install -e --id Python.Python.3.12 --accept-package-agreements --accept-source-agreements
    py -3.12 --version >nul 2>&1
    if errorlevel 1 (
        echo.
        echo Could not install Python 3.12 automatically.
        echo Please install "Python 3.12" ^(64-bit^) from https://www.python.org/downloads/
        echo then run this file again.
        pause
        exit /b 1
    )
)
py -3.12 --version

echo.
echo [2/4] Creating the environment C:\tf_env ...
if not exist C:\tf_env\Scripts\python.exe (
    py -3.12 -m venv C:\tf_env
)
if not exist C:\tf_env\Scripts\python.exe (
    echo Could not create C:\tf_env
    pause
    exit /b 1
)

echo.
echo [3/4] Installing numpy, tensorflow, xgboost (a few minutes) ...
C:\tf_env\Scripts\python.exe -m pip install --upgrade pip
C:\tf_env\Scripts\python.exe -m pip install numpy tensorflow xgboost
if errorlevel 1 (
    echo.
    echo Installation failed - see the message above and send it to me.
    pause
    exit /b 1
)

echo.
echo [4/4] Making SUMO's traci available in the new environment ...
if defined SUMO_HOME (
    echo %SUMO_HOME%\tools> C:\tf_env\Lib\site-packages\sumo_tools.pth
)
C:\tf_env\Scripts\python.exe -c "import traci" >nul 2>&1
if errorlevel 1 (
    echo traci not found through SUMO_HOME - installing it with pip ...
    C:\tf_env\Scripts\python.exe -m pip install traci
)

echo.
echo ---------------- check ----------------
C:\tf_env\Scripts\python.exe -c "import numpy, tensorflow as tf, xgboost, traci; print('OK  TensorFlow', tf.__version__, '| XGBoost', xgboost.__version__, '| traci imported')"
if errorlevel 1 (
    echo.
    echo The check failed - send me the message above.
) else (
    echo.
    echo All set. From now on start the simulation with run_defense.bat
)
pause
