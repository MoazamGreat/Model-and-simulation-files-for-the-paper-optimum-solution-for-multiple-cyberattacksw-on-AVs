"""
attack.py  -  ALL FIVE CAN-bus attacks at once (worst-case city)

Run:  python attack.py

Combines the five scenarios (DoS, Replay, Fuzzy, Gear spoofing, RPM spoofing). Each attack
is driven by the burst timeline of its own dataset, and all five hit the same city at the
same time (or staggered, see START_S below).

  Attack   | what a hit vehicle does                                            | colour
  ---------+--------------------------------------------------------------------+---------
  DOS      | controls frozen: keeps its speed, ignores red lights, cannot brake | magenta
  REPLAY   | follows its own speed from 5-20 s ago (stale commands)             | orange
  FUZZY    | random speed every second + random lane changes                    | cyan
  GEAR     | wrong gear: NEUTRAL (coasts to a stop)  or  RUNAWAY (accelerates)  | yellow / lime
  RPM      | false RPM: LIMITER (forced to crawl)  or  SURGE (hunting speed)    | blue / white

A vehicle is under one attack at a time. While it is hit it ignores the other attacks; when
its burst is over it recovers and can be hit again (by any attack).

Flow
  1. NORMAL     : clean traffic, a checkpoint every 10 s.
  2. INCIDENT   : the first burst (of any attack) after t=60 s hits the red "ego" car. A stopped
                  car in its lane makes the accident certain.
  3. RELOAD     : back to the last checkpoint.
  4. CITY_ATTACK: all five attacks hit the whole city, each following its dataset timeline.

Files used (same folder as this script):
  city.sumocfg + network/route files     (unchanged)
  all_attacks_timeline.json              (burst timelines of the 5 datasets; rebuilt from the
                                          five CSV files if missing)
It writes:
  all_attacks_log.csv   every burst / victim / recovery / crash, with the attack type
  checkpoints_all/      the saved states
"""
import os, csv, json, time, zlib, math
from bisect import bisect_left, bisect_right
from collections import deque
import traci

# ======================= SETTINGS (safe to change) =======================
ENABLED = {"DOS": True, "REPLAY": True, "FUZZY": True, "GEAR": True, "RPM": True}
# Sim second from which each attack is active. All 60 = all five at the same time.
# Stagger example: {"DOS": 60, "REPLAY": 120, "FUZZY": 180, "GEAR": 240, "RPM": 300}
START_S = {"DOS": 60, "REPLAY": 60, "FUZZY": 60, "GEAR": 60, "RPM": 60}
# Share of vehicles hit by an average burst of each attack (0.08 = 8 %).
INFECTION = {"DOS": 0.08, "REPLAY": 0.08, "FUZZY": 0.08, "GEAR": 0.08, "RPM": 0.08}

CHECKPOINT_EVERY_S = 10     # checkpoint every N sim seconds while traffic is clean
INCIDENT_TIMEOUT_S = 40     # reload anyway if the ego has not crashed this long after the attack
STALLED_CAR_AHEAD  = 90     # m: stopped car placed ahead of the ego
SIM_END_S          = 1500   # same as <end> in city.sumocfg
MAX_RELOADS        = 1
PAUSE_AFTER_CRASH  = 2.5    # real seconds to look at the wreck before reloading

# --- attack details ---
DOS_EGO_MIN_SPEED  = 14.0   # DOS    : speed (m/s) the frozen ego keeps
REPLAY_HOLD_S      = 8      # REPLAY : seconds a hit vehicle keeps replaying old commands
REPLAY_LAG_MIN_S, REPLAY_LAG_MAX_S = 5, 20   # REPLAY : age of the replayed command
HIST_S             = 30     # REPLAY : seconds of speed history remembered
FUZZY_MIN_SPEED    = 6.0    # FUZZY  : slowest random speed for the ego
FUZZY_MAX_SPEED    = 18.0   # FUZZY  : fastest random speed
FUZZY_SWERVE_PROB  = 0.25   # FUZZY  : chance per second to swerve to another lane
GEAR_NEUTRAL_SHARE = 0.5    # GEAR   : share of hit cars in NEUTRAL (rest: RUNAWAY)
GEAR_COAST_DECAY   = 0.85   # GEAR   : NEUTRAL speed multiplier per second
GEAR_ACCEL         = 2.5    # GEAR   : RUNAWAY m/s gained per second
GEAR_MAX_SPEED     = 18.0   # GEAR   : RUNAWAY top speed
RPM_LIMITER_SHARE  = 0.5    # RPM    : share of hit cars with LIMITER (rest: SURGE)
RPM_LIMITER_SPEED  = 3.0    # RPM    : crawl speed
RPM_LIMITER_DECEL  = 3.0    # RPM    : m/s lost per second until the crawl speed
RPM_SURGE_MEAN     = 11.0
RPM_SURGE_AMP      = 7.0
RPM_SURGE_PERIOD_S = 6

USE_GUI = os.environ.get("SUMO_NOGUI") is None   # SUMO_NOGUI=1 -> headless test
# ==========================================================================

ORDER = ["DOS", "REPLAY", "FUZZY", "GEAR", "RPM"]          # also the priority order
LABEL = {"DOS": "DoS", "REPLAY": "Replay", "FUZZY": "Fuzzy", "GEAR": "Gear spoofing",
         "RPM": "RPM spoofing"}
CSV_FILES = {"DOS": "DoS_dataset_30pct.csv", "REPLAY": "Replay_dataset_30pct.csv",
             "FUZZY": "Fuzzy_dataset_30pct.csv", "GEAR": "gear_dataset_30pct.csv",
             "RPM": "RPM_dataset_30pct.csv"}
COLORS = {("DOS", ""): (255, 0, 255, 255),          # magenta
          ("REPLAY", ""): (255, 140, 0, 255),       # orange
          ("FUZZY", ""): (0, 220, 255, 255),        # cyan
          ("GEAR", "NEUTRAL"): (255, 230, 0, 255),  # yellow
          ("GEAR", "RUNAWAY"): (0, 255, 60, 255),   # lime
          ("RPM", "LIMITER"): (40, 90, 255, 255),   # blue
          ("RPM", "SURGE"): (255, 255, 255, 255)}   # white

HERE = os.path.dirname(os.path.abspath(__file__))
CFG = os.path.join(HERE, "city.sumocfg")
CKPT_DIR = os.path.join(HERE, "checkpoints_all")
LOG_FILE = os.path.join(HERE, "all_attacks_log.csv")
TIMELINE_JSON = os.path.join(HERE, "all_attacks_timeline.json")


# ----------------------- 1. datasets -> attack timelines -----------------------
def build_timeline_json():
    """For every dataset count, per second, all CAN messages and attack ('T') messages."""
    data = {}
    for name in ORDER:
        path = os.path.join(HERE, CSV_FILES[name])
        print("reading", path, flush=True)
        total, attack, t0 = {}, {}, None
        with open(path) as f:
            for line in f:
                p = line.strip().split(",")
                ts = float(p[0])
                if t0 is None:
                    t0 = ts
                s = int(ts - t0)
                total[s] = total.get(s, 0) + 1
                if p[-1] == "T":
                    attack[s] = attack.get(s, 0) + 1
        n = max(total) + 1
        data[name] = {"total": [total.get(i, 0) for i in range(n)],
                      "attack": [attack.get(i, 0) for i in range(n)]}
    with open(TIMELINE_JSON, "w") as f:
        json.dump(data, f)
    return data


class Timeline:
    """Attack 'windows' = runs of consecutive dataset seconds that contain attack messages."""
    def __init__(self, name, data):
        self.name = name
        self.total, self.attack = data["total"], data["attack"]
        n = len(self.total)
        self.win_of = [-1] * n
        self.windows = []
        cur = None
        for i in range(n):
            if self.attack[i] > 0:
                if cur is None:
                    cur = {"start": i, "end": i, "atk": 0, "tot": 0}
                    self.windows.append(cur)
                cur["end"] = i
                cur["atk"] += self.attack[i]
                cur["tot"] += self.total[i]
                self.win_of[i] = len(self.windows) - 1
            else:
                cur = None
        for w in self.windows:
            w["ratio"] = w["atk"] / max(1, w["tot"])
        self.starts = [w["start"] for w in self.windows]
        self.mean_ratio = sum(w["ratio"] for w in self.windows) / len(self.windows)

    def burst_at(self, sec):
        """Burst going on right now in the dataset (or -1)."""
        return self.win_of[sec] if 0 <= sec < len(self.win_of) else -1

    def active(self, sec):
        """Bursts whose effect is in force at this second."""
        if self.name == "REPLAY":                      # replayed commands outlive the burst
            return range(bisect_left(self.starts, sec - REPLAY_HOLD_S + 1),
                         bisect_right(self.starts, sec))
        b = self.burst_at(sec)
        return [b] if b >= 0 else []

    def until(self, wid):
        w = self.windows[wid]
        return w["start"] + REPLAY_HOLD_S if self.name == "REPLAY" else w["end"] + 1

    def hit_probability(self, wid):
        """Stronger bursts (higher share of attack frames) hit more vehicles."""
        return min(1.0, INFECTION[self.name] * self.windows[wid]["ratio"] / self.mean_ratio)


def dice(veh_id, wid, salt):
    """Deterministic 'random' number in [0,1): same vehicle + burst + salt -> same answer."""
    return zlib.crc32(("%s:%d:%s" % (veh_id, wid, salt)).encode()) / 2**32


def dice_sec(veh_id, sec, salt):
    return zlib.crc32(("%s:s%d:%s" % (veh_id, sec, salt)).encode()) / 2**32


# ----------------------- 2. the five attack behaviours -----------------------
def stale_speed(hist, lag, current):                      # REPLAY
    if not hist:
        return current
    return hist[-lag] if len(hist) >= lag else hist[0]


def fuzz_speed(veh, sec, lo=0.0):                         # FUZZY
    return lo + dice_sec(veh, sec, "spd") * (FUZZY_MAX_SPEED - lo)


def fuzz_swerve(veh, sec):                                # FUZZY
    if dice_sec(veh, sec, "lc") < FUZZY_SWERVE_PROB:
        direction = 1 if dice_sec(veh, sec, "dir") < 0.5 else -1
        try:
            traci.vehicle.changeLaneRelative(veh, direction, 2.0)
        except (traci.TraCIException, AttributeError):
            pass


def runaway_speed(current):                               # GEAR
    return min(GEAR_MAX_SPEED, current + GEAR_ACCEL)


def gear_speed(mode, current):                            # GEAR
    if mode == "NEUTRAL":
        v = current * GEAR_COAST_DECAY
        return 0.0 if v < 0.3 else v
    return runaway_speed(current)


def surge_speed(veh, sec):                                # RPM
    phase = zlib.crc32(veh.encode()) % RPM_SURGE_PERIOD_S
    v = RPM_SURGE_MEAN + RPM_SURGE_AMP * math.sin(2 * math.pi * (sec + phase) / RPM_SURGE_PERIOD_S)
    return max(0.0, v)


def rpm_speed(veh, mode, sec, current):                   # RPM
    if mode == "LIMITER":
        return max(RPM_LIMITER_SPEED, current - RPM_LIMITER_DECEL)
    return surge_speed(veh, sec)


def attack_speed(veh, st, sec, hist):
    """Speed a hit vehicle is forced to follow this second, depending on its attack."""
    typ = st["type"]
    cur = traci.vehicle.getSpeed(veh)
    if typ == "DOS":
        return st["speed0"]
    if typ == "REPLAY":
        return stale_speed(hist.get(veh), st["lag"], cur)
    if typ == "FUZZY":
        fuzz_swerve(veh, sec)
        return fuzz_speed(veh, sec)
    if typ == "GEAR":
        return gear_speed(st["mode"], cur)
    return rpm_speed(veh, st["mode"], sec, cur)


def ego_speed(typ, sec, hist):
    """What the ego does in the incident, for the attack that hit it first."""
    cur = traci.vehicle.getSpeed("ego")
    if typ == "DOS":
        return max(DOS_EGO_MIN_SPEED, cur)
    if typ == "REPLAY":
        return max(DOS_EGO_MIN_SPEED, max(hist.get("ego", [0]) or [0]))
    if typ == "FUZZY":
        return fuzz_speed("ego", sec, FUZZY_MIN_SPEED)
    if typ == "GEAR":
        return runaway_speed(cur)
    return surge_speed("ego", sec)


# ----------------------- 3. helpers -----------------------
class Log:
    def __init__(self):
        self.f = open(LOG_FILE, "w", newline="")
        self.w = csv.writer(self.f)
        self.w.writerow(["sim_time", "scenario", "event", "attack", "vehicle", "window_id",
                         "dataset_second", "attack_ratio", "detail"])

    def add(self, t, scenario, event, attack="", veh="", wid="", sec="", ratio="", detail=""):
        self.w.writerow([round(t, 1), scenario, event, attack, veh, wid, sec,
                         ratio if ratio == "" else round(ratio, 3), detail])
        self.f.flush()


def banner(text):
    print("\n" + "=" * 70 + "\n  " + text + "\n" + "=" * 70, flush=True)


def restore(veh, color=None):
    try:
        traci.vehicle.setSpeedMode(veh, 31)
        traci.vehicle.setLaneChangeMode(veh, 1621)
        traci.vehicle.setSpeed(veh, -1)
        if color is not None:
            traci.vehicle.setColor(veh, color)
    except traci.TraCIException:
        pass


def place_stalled_car(ego="ego"):
    """Put a stopped car in the ego's lane ahead of it. Returns True once placed."""
    edge = traci.vehicle.getRoadID(ego)
    if edge.startswith(":"):
        return False
    pos = traci.vehicle.getLanePosition(ego)
    length = traci.lane.getLength(traci.vehicle.getLaneID(ego))
    if length - pos < 50:
        return False
    at = min(pos + STALLED_CAR_AHEAD, length - 8)
    try:
        traci.route.add("obstacle_route", [edge])
        traci.vehicle.add("obstacle", "obstacle_route", typeID="car", depart="now",
                          departLane=str(traci.vehicle.getLaneIndex(ego)),
                          departPos=str(at), departSpeed="0")
        traci.vehicle.setSpeedMode("obstacle", 0)
        traci.vehicle.setSpeed("obstacle", 0)
        traci.vehicle.setColor("obstacle", (120, 120, 120, 255))
    except traci.TraCIException:
        return False
    return True


def load_timelines():
    if os.path.exists(TIMELINE_JSON):
        with open(TIMELINE_JSON) as f:
            data = json.load(f)
    else:
        print("all_attacks_timeline.json not found -> building it from the five CSV files "
              "(takes about a minute)", flush=True)
        data = build_timeline_json()
    return {name: Timeline(name, data[name]) for name in ORDER}


# ----------------------- 4. main simulation -----------------------
def main():
    tls = load_timelines()
    types = [n for n in ORDER if ENABLED[n]]
    log = Log()
    os.makedirs(CKPT_DIR, exist_ok=True)

    cmd = ["sumo-gui" if USE_GUI else "sumo", "-c", CFG,
           "--collision.check-junctions", "true",
           "--collision.action", "warn",
           "--collision.stoptime", "8",
           "--no-step-log", "true"]
    if USE_GUI:
        cmd += ["--delay", "60", "--start"]
    traci.start(cmd)

    scenario = "NORMAL"
    tracked = False
    last_ckpt, last_ckpt_sec, ckpt_hist = None, -1, {}
    incident_t0 = crash_t = incident_type = None
    reloads = 0
    obstacle_placed = False
    hist = {}            # vehicle -> recent natural speeds (needed by REPLAY)
    held = {}            # vehicle -> state of the attack it is currently under
    orig_color = {}
    seen_collisions = set()
    stats = {n: {"victims": set(), "windows": set(), "collisions": 0} for n in ORDER}
    stats["NONE"] = {"collisions": 0}

    banner("SCENARIO 1/3  NORMAL traffic (checkpoints every %d s)" % CHECKPOINT_EVERY_S)

    while traci.simulation.getMinExpectedNumber() > 0:
        traci.simulationStep()
        t = traci.simulation.getTime()
        if t >= SIM_END_S:
            break
        sec = int(t)
        ids = traci.vehicle.getIDList()
        idset = set(ids)
        ego_here = "ego" in idset

        # --- remember natural speeds (what could be replayed later) ---
        for v in ids:
            if v in held or (v == "ego" and scenario == "INCIDENT"):
                continue
            h = hist.get(v)
            if h is None:
                h = hist[v] = deque(maxlen=HIST_S)
            h.append(traci.vehicle.getSpeed(v))
        for v in [v for v in hist if v not in idset]:
            del hist[v]

        # --- ego camera + highlight ---
        if ego_here:
            if not tracked:
                if USE_GUI:
                    traci.gui.trackVehicle("View #0", "ego")
                    traci.gui.setZoom("View #0", 900)
                tracked = True
            traci.vehicle.highlight("ego", (255, 0, 0, 255), size=10)

        # --- collisions this step ---
        ego_hit = False
        for c in traci.simulation.getCollisions():
            key = (scenario, c.collider, c.victim)
            if key in seen_collisions:
                continue
            seen_collisions.add(key)
            att = (held.get(c.collider) or held.get(c.victim) or {}).get("type")
            if att is None and scenario == "INCIDENT" and "ego" in (c.collider, c.victim):
                att = incident_type
            stats[att or "NONE"]["collisions"] += 1
            if "ego" in (c.collider, c.victim):
                ego_hit = True
            log.add(t, scenario, "COLLISION", att or "", c.collider, "", sec,
                    detail="victim=%s edge=%s" % (c.victim, c.lane.rsplit("_", 1)[0]))

        # ================= scenario logic =================
        if scenario == "NORMAL":
            if sec % CHECKPOINT_EVERY_S == 0 and sec != last_ckpt_sec:
                last_ckpt = os.path.join(CKPT_DIR, "ckpt_%04d.xml" % sec)
                traci.simulation.saveState(last_ckpt)
                last_ckpt_sec = sec
                ckpt_hist = {v: list(d) for v, d in hist.items()}
                log.add(t, scenario, "CHECKPOINT", detail=os.path.basename(last_ckpt))
            for n in types:                                 # first burst of any attack
                wid = tls[n].burst_at(sec)
                if t >= START_S[n] and wid >= 0:
                    scenario, incident_t0, incident_type = "INCIDENT", t, n
                    w = tls[n].windows[wid]
                    banner("SCENARIO 2/3  %s ATTACK on the driver (t=%.0f s, dataset burst #%d, "
                           "%.0f%% attack frames)" % (LABEL[n].upper(), t, wid, 100 * w["ratio"]))
                    log.add(t, scenario, "ATTACK_START", n, "ego", wid, sec, w["ratio"],
                            "last checkpoint=%s" % os.path.basename(last_ckpt))
                    break

        elif scenario == "INCIDENT":
            if ego_here:
                traci.vehicle.setSpeedMode("ego", 0)
                traci.vehicle.setLaneChangeMode("ego", 0)
                traci.vehicle.setSpeed("ego", ego_speed(incident_type, sec, hist))
                if not obstacle_placed:
                    obstacle_placed = place_stalled_car("ego")
                    if obstacle_placed:
                        log.add(t, scenario, "STALLED_CAR", incident_type, "obstacle",
                                detail="placed ahead of ego")
            if crash_t is None and ego_hit:
                crash_t = t
                banner("ACCIDENT! The ego car (%s attack) crashed at t=%.0f s"
                       % (LABEL[incident_type], t))
                log.add(t, scenario, "EGO_CRASH", incident_type, "ego", "", sec)
            elif crash_t is None and t - incident_t0 >= INCIDENT_TIMEOUT_S:
                crash_t = t
                banner("No crash within %d s - treating the loss of control as the incident"
                       % INCIDENT_TIMEOUT_S)
                log.add(t, scenario, "INCIDENT_TIMEOUT", incident_type, "ego")
            if crash_t is not None and t >= crash_t + 3:
                if reloads >= MAX_RELOADS or last_ckpt is None:
                    scenario = "CITY_ATTACK"
                else:
                    if USE_GUI:
                        time.sleep(PAUSE_AFTER_CRASH)
                    banner("RELOAD  back to checkpoint %s (sim time %d s)" %
                           (os.path.basename(last_ckpt), last_ckpt_sec))
                    traci.simulation.loadState(last_ckpt)
                    reloads += 1
                    restore("ego", orig_color.get("ego"))
                    held.clear()
                    hist = {v: deque(l, maxlen=HIST_S) for v, l in ckpt_hist.items()}
                    tracked = False
                    scenario = "CITY_ATTACK"
                    log.add(traci.simulation.getTime(), scenario, "RELOAD", "", "",
                            detail=os.path.basename(last_ckpt))
                    banner("SCENARIO 3/3  ALL FIVE ATTACKS on the whole city (%s)" %
                           ", ".join(LABEL[n] for n in types))
                    continue

        elif scenario == "CITY_ATTACK":
            # which bursts are in force right now (only once the attack has started)
            actives = {n: (tls[n].active(sec) if t >= START_S[n] else []) for n in types}
            for n in types:
                for wid in actives[n]:
                    if wid not in stats[n]["windows"]:
                        stats[n]["windows"].add(wid)
                        log.add(t, scenario, "WINDOW_START", n, "", wid, sec,
                                tls[n].windows[wid]["ratio"],
                                "p_hit=%.2f" % tls[n].hit_probability(wid))

            # 1) vehicles already under attack: extend, recover, or keep applying
            for v in list(held):
                st = held[v]
                if v not in idset:                           # left the map
                    held.pop(v)
                    continue
                for wid in actives[st["type"]]:              # same attack hits again -> extend
                    if dice(v, wid, st["type"]) < tls[st["type"]].hit_probability(wid):
                        st["until"] = max(st["until"], tls[st["type"]].until(wid))
                if sec >= st["until"]:                       # burst over -> recover
                    restore(v, orig_color.get(v))
                    held.pop(v)
                    log.add(t, scenario, "RECOVER", st["type"], v, "", sec)

            # 2) free vehicles can be hit by any attack (priority = ORDER)
            for v in ids:
                if v in held:
                    continue
                for n in types:
                    hit = next((wid for wid in actives[n]
                                if dice(v, wid, n) < tls[n].hit_probability(wid)), None)
                    if hit is None:
                        continue
                    cur = traci.vehicle.getSpeed(v)
                    st = {"type": n, "wid": hit, "until": tls[n].until(hit), "speed0": cur,
                          "mode": ""}
                    if n == "REPLAY":
                        st["lag"] = REPLAY_LAG_MIN_S + int(
                            dice(v, hit, "lag") * (REPLAY_LAG_MAX_S - REPLAY_LAG_MIN_S + 1))
                    elif n == "GEAR":
                        st["mode"] = "NEUTRAL" if dice(v, hit, "gear") < GEAR_NEUTRAL_SHARE else "RUNAWAY"
                    elif n == "RPM":
                        st["mode"] = "LIMITER" if dice(v, hit, "rpm") < RPM_LIMITER_SHARE else "SURGE"
                    orig_color[v] = traci.vehicle.getColor(v)
                    traci.vehicle.setSpeedMode(v, 0)
                    if n != "REPLAY":
                        traci.vehicle.setLaneChangeMode(v, 0)
                    traci.vehicle.setColor(v, COLORS[(n, st["mode"] if n in ("GEAR", "RPM") else "")])
                    held[v] = st
                    stats[n]["victims"].add(v)
                    log.add(t, scenario, "VICTIM", n, v, hit, sec, tls[n].windows[hit]["ratio"],
                            "%sedge=%s speed=%.1f" % (
                                (st["mode"] + " ") if st["mode"] else "",
                                traci.vehicle.getRoadID(v), cur))
                    break

            # 3) every hit vehicle follows its attack's forced speed this second
            for v, st in held.items():
                traci.vehicle.setSpeed(v, attack_speed(v, st, sec, hist))

    log.add(traci.simulation.getTime(), scenario, "END", detail=", ".join(
        "%s: windows=%d victims=%d collisions=%d" % (n, len(stats[n]["windows"]),
                                                    len(stats[n]["victims"]), stats[n]["collisions"])
        for n in types))
    lines = ["DONE  (log: all_attacks_log.csv)"]
    for n in types:
        lines.append("  %-14s bursts: %3d | vehicles hit: %4d | collisions: %4d" % (
            LABEL[n], len(stats[n]["windows"]), len(stats[n]["victims"]), stats[n]["collisions"]))
    lines.append("  %-14s collisions between unaffected vehicles: %d" % ("(none)", stats["NONE"]["collisions"]))
    banner("\n  ".join(lines))
    traci.close()


if __name__ == "__main__":
    main()
