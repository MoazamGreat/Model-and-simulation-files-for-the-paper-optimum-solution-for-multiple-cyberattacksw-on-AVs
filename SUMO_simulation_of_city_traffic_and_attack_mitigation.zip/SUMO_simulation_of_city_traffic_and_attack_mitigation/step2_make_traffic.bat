@echo off
cd /d "%~dp0"
if "%SUMO_HOME%"=="" (echo SUMO_HOME is not set & pause & exit /b 1)
set RT=python "%SUMO_HOME%\tools\randomTrips.py" -n city_base.net.xml -e 900 --fringe-factor 3
set TA=departLane='best' departSpeed='max'
%RT% --prefix car  -p 1.2 --trip-attributes="type='car' %TA%"       -o car.trips.xml
%RT% --prefix suv  -p 4   --trip-attributes="type='suv' %TA%"       -o suv.trips.xml
%RT% --prefix taxi -p 8   --trip-attributes="type='taxi' %TA%"      -o taxi.trips.xml
%RT% --prefix van  -p 8   --trip-attributes="type='van' %TA%"       -o van.trips.xml
%RT% --prefix bus  -p 20  --trip-attributes="type='bus' %TA%"       -o bus.trips.xml
%RT% --prefix trk  -p 10  --trip-attributes="type='truck' %TA%"     -o truck.trips.xml
%RT% --prefix bike -p 4   --trip-attributes="type='motorbike' %TA%" -o motorbike.trips.xml
%RT% --prefix cyc  -p 6   --trip-attributes="type='bicycle' departLane='best'" -o bicycle.trips.xml
%RT% --prefix amb  -p 150 --trip-attributes="type='ambulance' %TA%" -o ambulance.trips.xml
python "%SUMO_HOME%\tools\randomTrips.py" -n city_base.net.xml -e 900 --pedestrians --prefix ped -p 1.0 --max-distance 600 -o ped.rou.xml
echo.
echo Step 2 finished. Check for errors above.
pause
