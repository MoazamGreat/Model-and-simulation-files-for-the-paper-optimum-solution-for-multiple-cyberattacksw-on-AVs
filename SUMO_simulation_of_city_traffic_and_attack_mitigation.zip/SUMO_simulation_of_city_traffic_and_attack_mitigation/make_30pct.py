"""
make_30pct.py - builds the *_30pct.csv files that the simulation reads.

The simulation uses the LAST 30% of the rows of each Car-Hacking CSV (the part that is not
used for training). Download the original CSVs (see README.md) and run:

    python make_30pct.py --raw-dir path/to/Car-Hacking-Dataset

Input names:   DoS_dataset.csv  Fuzzy_dataset.csv  gear_dataset.csv  RPM_dataset.csv
Output names:  DoS_dataset_30pct.csv  Fuzzy_dataset_30pct.csv  gear_dataset_30pct.csv  RPM_dataset_30pct.csv
(Replay_dataset_30pct.csv is already in this folder; it is the synthetic Replay set.)
"""
import argparse, os

ap = argparse.ArgumentParser()
ap.add_argument("--raw-dir", required=True)
ap.add_argument("--out-dir", default=os.path.dirname(os.path.abspath(__file__)))
a = ap.parse_args()

for name in ("DoS", "Fuzzy", "gear", "RPM"):
    src = os.path.join(a.raw_dir, f"{name}_dataset.csv")
    dst = os.path.join(a.out_dir, f"{name}_dataset_30pct.csv")
    with open(src, "rb") as fh:
        n = sum(1 for _ in fh)
    keep_from = int(n * 0.70)
    with open(src, "rb") as fi, open(dst, "wb") as fo:
        for i, line in enumerate(fi):
            if i >= keep_from:
                fo.write(line)
    print(f"{name}: {n:,} rows -> last {n - keep_from:,} rows written to {dst}")
