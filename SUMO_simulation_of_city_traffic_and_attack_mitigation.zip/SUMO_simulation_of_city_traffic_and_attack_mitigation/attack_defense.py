"""
attack_defense.py  -  all five CAN-bus attacks + the Hybrid-Lite DCNN/XGBoost defence

Run:      python attack_defense.py
Options:  --retrain     ignore the saved model and train it again
          --quick       smaller / faster training (for slow computers)
          --no-defense  same attacks, model NOT deployed (to compare)

WHAT HAPPENS
  1. SUMO starts at once and the city runs normally (same as run_normal.py).
  2. In the background the model is trained on all five datasets (DoS, Fuzzy, Gear, RPM,
     Replay): DCNN_Lite -> 64-d embedding -> int8 TFLite -> compiled XGBoost.
     The trained model is saved in  defense_model/  so the next runs start at once.
  3. At t = 60 s the model is DEPLOYED and the five attacks start hitting the city
     (burst timelines taken from the datasets, as in attack.py).
     If training is not finished yet, the simulation waits at t = 60 s.
  4. DETECTION: every vehicle has a CAN-bus gateway. Each second the model looks at one
     29x29 frame (29 CAN IDs as bits) of that vehicle's bus. When a vehicle is under
     attack its bus carries the real attack frames of the matching dataset; otherwise it
     carries real normal traffic. A frame classified as "attack" raises an alarm.
  5. MITIGATION: one second after the alarm the vehicle goes into SAFE MODE: the spoofed /
     injected / replayed commands are rejected and the normal driving logic is restored
     (the vehicle turns dark green). Safe mode is kept for SHIELD_HOLD_S seconds after
     the last alarm.

  Colours:  magenta DoS | orange Replay | cyan Fuzzy | yellow/lime Gear | blue/white RPM
            dark green = protected (safe mode)

Needs in the same folder: city.sumocfg + network files, the five CSV files
(DoS_dataset_30pct.csv, Fuzzy_dataset_30pct.csv, gear_dataset_30pct.csv,
RPM_dataset_30pct.csv, Replay_dataset_30pct.csv) and all_attacks_timeline.json.
Python packages: numpy, tensorflow, xgboost (setup_tf_env.bat installs them)
It writes: defense_log.csv (every attack, detection, mitigation, false alarm, crash)
"""
import os, sys, csv, json, time, zlib, math, gc, shutil, subprocess, ctypes, pathlib
import threading, traceback, importlib.util

# A stray file/folder called "pandas" (or numpy, xgboost ...) inside the project folder would hide the
# real library from Keras/XGBoost. Python puts this folder first on the search path, so remove it.
_HERE = os.path.dirname(os.path.abspath(__file__))
sys.path[:] = [p for p in sys.path if os.path.abspath(p or os.getcwd()) != _HERE]
from bisect import bisect_left, bisect_right
from collections import deque
import numpy as np
import traci

os.environ.setdefault("TF_CPP_MIN_LOG_LEVEL", "3")

# ============================== SETTINGS (safe to change) ==============================
# ---------- defence ----------
DEFENSE_ENABLED   = "--no-defense" not in sys.argv
DEPLOY_S          = 60      # sim second at which the model is deployed and the attacks start
MITIGATION_DELAY_S = 1      # seconds between the alarm and the safe mode (response time)
SHIELD_HOLD_S     = 8       # safe mode is kept this long after the last alarm
CONFIRM_K, CONFIRM_N = 1, 1 # alarm if K of the last N frames are "attack" (1 of 1 = fastest)
SHIELD_COLOR      = (0, 120, 0, 255)   # dark green = protected
EGO_TARGET_BOOST  = 6.0     # the red driver car is attacked this many times more often

# ---------- model / training (same settings as hybrid_lite.py, with smaller data) ----------
TRAIN_ROWS        = 40_000  # CSV rows per dataset used for training (notebook: 150,000)
HOLDOUT_ROWS      = 10_000  # rows right after the training rows, used only for the test report
EPOCHS            = 5       # notebook: 10 (EarlyStopping patience 2)
BATCH_SIZE        = 512
LR_PEAK, LR_MIN   = 1e-3, 1e-5
WINDOW            = 29
TEST_FRAC         = 0.30
EMBEDDING_DIM     = 64
N_CALIB           = 256     # frames for int8 calibration
XGB_N_TREES, XGB_MAX_DEPTH, XGB_LR = 100, 6, 0.1
if "--quick" in sys.argv:
    TRAIN_ROWS, HOLDOUT_ROWS, EPOCHS = 15_000, 5_000, 3

# ---------- attacks (same as attack.py) ----------
ENABLED   = {"DOS": True, "REPLAY": True, "FUZZY": True, "GEAR": True, "RPM": True}
START_S   = {"DOS": 60, "REPLAY": 60, "FUZZY": 60, "GEAR": 60, "RPM": 60}
INFECTION = {"DOS": 0.08, "REPLAY": 0.08, "FUZZY": 0.08, "GEAR": 0.08, "RPM": 0.08}
SIM_END_S = 1500
DOS_EGO_MIN_SPEED = 14.0
REPLAY_HOLD_S = 8
REPLAY_LAG_MIN_S, REPLAY_LAG_MAX_S = 5, 20
HIST_S = 30
FUZZY_MAX_SPEED, FUZZY_SWERVE_PROB = 18.0, 0.25
GEAR_NEUTRAL_SHARE, GEAR_COAST_DECAY, GEAR_ACCEL, GEAR_MAX_SPEED = 0.5, 0.85, 2.5, 18.0
RPM_LIMITER_SHARE, RPM_LIMITER_SPEED, RPM_LIMITER_DECEL = 0.5, 3.0, 3.0
RPM_SURGE_MEAN, RPM_SURGE_AMP, RPM_SURGE_PERIOD_S = 11.0, 7.0, 6
USE_GUI = os.environ.get("SUMO_NOGUI") is None
# =======================================================================================

ORDER = ["DOS", "REPLAY", "FUZZY", "GEAR", "RPM"]
LABEL = {"DOS": "DoS", "REPLAY": "Replay", "FUZZY": "Fuzzy", "GEAR": "Gear spoofing",
         "RPM": "RPM spoofing"}
CSV_FILES = {"DOS": "DoS_dataset_30pct.csv", "REPLAY": "Replay_dataset_30pct.csv",
             "FUZZY": "Fuzzy_dataset_30pct.csv", "GEAR": "gear_dataset_30pct.csv",
             "RPM": "RPM_dataset_30pct.csv"}
COLORS = {("DOS", ""): (255, 0, 255, 255), ("REPLAY", ""): (255, 140, 0, 255),
          ("FUZZY", ""): (0, 220, 255, 255), ("GEAR", "NEUTRAL"): (255, 230, 0, 255),
          ("GEAR", "RUNAWAY"): (0, 255, 60, 255), ("RPM", "LIMITER"): (40, 90, 255, 255),
          ("RPM", "SURGE"): (255, 255, 255, 255)}

HERE = os.path.dirname(os.path.abspath(__file__))
CFG = os.path.join(HERE, "city.sumocfg")
TIMELINE_JSON = os.path.join(HERE, "all_attacks_timeline.json")
LOG_FILE = os.path.join(HERE, "defense_log.csv")
MODEL_DIR = os.path.join(HERE, "defense_model" + ("_quick" if "--quick" in sys.argv else ""))
FORCE_RETRAIN = "--retrain" in sys.argv
TEST_MAX_ROWS = int(os.environ["DEFENSE_MAX_ROWS"]) if os.environ.get("DEFENSE_MAX_ROWS") else None

COLS = ["Timestamp", "CAN_ID", "DLC", "D0", "D1", "D2", "D3", "D4", "D5", "D6", "D7", "Flag"]
SHIFTS = np.arange(28, -1, -1, dtype=np.int32)      # 29 CAN-ID bits, MSB first (as notebook)
NORMAL_POOL = 20000


def mlog(msg):
    print("[model] " + msg, flush=True)


def banner(text):
    print("\n" + "=" * 72 + "\n  " + text + "\n" + "=" * 72, flush=True)


# ======================================================================================
# 1. DATA  (CSV -> CAN-ID bits).  Same bit encoding and 29x29 frames as the notebook.
# ======================================================================================
class DatasetArrays:
    """One dataset kept in memory as arrays: ID bits, attack flags, and per-second index."""
    def __init__(self, name):
        path = os.path.join(HERE, CSV_FILES[name])
        ts_l, id_l, fl_l = [], [], []
        t_first = None
        need = TRAIN_ROWS + HOLDOUT_ROWS
        with open(path, "r") as fh:                      # plain Python: no pandas needed
            for i, line in enumerate(fh):
                p = line.rstrip().split(",")
                ts = float(p[0])
                if t_first is None:
                    t_first = ts
                if i >= need and ts - t_first >= SIM_END_S + 5:
                    break                                # rows after the simulation horizon are not needed
                if TEST_MAX_ROWS and i >= TEST_MAX_ROWS:
                    break
                ts_l.append(ts)
                id_l.append(p[1])
                fl_l.append(p[-1].strip() == "T")
        ts = np.array(ts_l, dtype=np.float64)
        flags = np.array(fl_l, dtype=np.uint8)
        ids = id_l
        del ts_l, fl_l
        gc.collect()
        n = len(ids)
        int_ids = np.fromiter((int(x.strip(), 16) for x in ids), dtype=np.int32, count=n)
        del ids, id_l
        bits = np.empty((n, 29), dtype=np.uint8)
        for a in range(0, n, 200_000):                       # chunked: keeps memory small
            b = int_ids[a:a + 200_000]
            bits[a:a + len(b)] = (b[:, None] >> SHIFTS[None, :]) & 1
        self.name, self.bits, self.flags = name, bits, flags
        secs = np.floor(ts - ts[0]).astype(np.int64)
        self.sec_ptr = np.searchsorted(secs, np.arange(int(secs[-1]) + 2))   # first row of each second
        self.atk_idx = np.flatnonzero(flags)
        csum = np.concatenate([[0], np.cumsum(flags, dtype=np.int64)])
        win = csum[WINDOW:] - csum[:-WINDOW]                  # attack rows inside each window
        starts = np.flatnonzero(win == 0)                     # windows that are 100 % normal
        if len(starts) > NORMAL_POOL:
            starts = starts[np.linspace(0, len(starts) - 1, NORMAL_POOL).astype(np.int64)]
        self.normal_starts = starts
        self.n = n

    def frames(self, start, stop):
        """Sliding 29x29 frames of rows [start, stop) -> X uint8 (N,29,29), y (N,) (1 = any attack)."""
        b = np.ascontiguousarray(self.bits[start:stop])
        f = np.ascontiguousarray(self.flags[start:stop])
        n = len(b) - WINDOW + 1
        X = np.lib.stride_tricks.as_strided(
            b, shape=(n, WINDOW, 29), strides=(b.strides[0], b.strides[0], b.strides[1])).copy()
        fw = np.lib.stride_tricks.as_strided(f, shape=(n, WINDOW), strides=(f.strides[0], f.strides[0]))
        return X, fw.max(axis=1).astype(np.int8)


def load_all_datasets(log=mlog):
    store = {}
    for name in ORDER:
        t0 = time.time()
        store[name] = DatasetArrays(name)
        d = store[name]
        log("loaded %-6s rows=%9s  attack rows=%8s  (%.0fs)" % (name, format(d.n, ","),
                                                              format(len(d.atk_idx), ","), time.time() - t0))
    return store


# ======================================================================================
# 2. MODEL  (notebook model, made portable: no Lambda layers, no Colab, no mixed precision)
# ======================================================================================
def lazy_tf():
    import tensorflow as tf
    from tensorflow import keras
    from tensorflow.keras import layers
    return tf, keras, layers


def build_dcnn_lite(embedding_dim=EMBEDDING_DIM):
    tf, keras, layers = lazy_tf()

    def cbr(x, f, k, strides=1):
        x = layers.Conv2D(f, k, strides=strides, padding="same", use_bias=False)(x)
        x = layers.BatchNormalization()(x)
        return layers.Activation("relu")(x)

    inp = keras.Input(shape=(29, 29, 1))
    x = cbr(inp, 16, 3)
    x = cbr(x, 16, 3)
    x = layers.MaxPooling2D(2, strides=2, padding="same")(x)
    x = cbr(x, 32, 3)
    ch = x.shape[-1]
    b1 = cbr(x, 16, 1)                                   # lightweight Inception-ResNet block
    b2 = cbr(cbr(x, 16, 1), 16, 3)
    m = layers.Concatenate()([b1, b2])
    m = layers.Conv2D(ch, 1, padding="same", use_bias=False)(m)
    m = layers.BatchNormalization()(m)
    m = layers.Rescaling(0.1)(m)                         # == the notebook's  x + 0.1 * m
    x = layers.Add()([x, m])
    x = layers.Activation("relu")(x)
    x = cbr(x, 64, 3, strides=2)
    x = layers.GlobalAveragePooling2D()(x)
    x = layers.Dropout(0.2)(x)
    emb = layers.Dense(embedding_dim, activation="relu", name="feature_embedding")(x)
    out = layers.Dense(2, activation="softmax", name="pretrain_head")(emb)   # training only
    return keras.Model(inp, out, name="DCNN_Lite")


def make_lr(steps_per_epoch, epochs):
    tf, keras, layers = lazy_tf()
    total = steps_per_epoch * epochs
    try:
        return keras.optimizers.schedules.CosineDecay(
            initial_learning_rate=LR_PEAK, decay_steps=max(total - steps_per_epoch, 1),
            alpha=LR_MIN / LR_PEAK, warmup_target=LR_PEAK, warmup_steps=steps_per_epoch)
    except TypeError:                                    # older Keras without warm-up arguments
        return keras.optimizers.schedules.CosineDecay(
            initial_learning_rate=LR_PEAK, decay_steps=max(total, 1), alpha=LR_MIN / LR_PEAK)


def metrics(y_true, y_pred):
    TP = int(((y_pred == 1) & (y_true == 1)).sum())
    TN = int(((y_pred == 0) & (y_true == 0)).sum())
    FP = int(((y_pred == 1) & (y_true == 0)).sum())
    FN = int(((y_pred == 0) & (y_true == 1)).sum())
    P = TP / (TP + FP) if (TP + FP) else 0.0
    R = TP / (TP + FN) if (TP + FN) else 0.0
    return dict(frames=len(y_true), attack_frames=TP + FN, recall=R, precision=P,
                FNR_pct=100.0 * FN / (TP + FN) if (TP + FN) else 0.0,
                FPR_pct=100.0 * FP / (FP + TN) if (FP + TN) else 0.0,
                F1=2 * P * R / (P + R) if (P + R) else 0.0)


# ---------------- compiled XGBoost (notebook: trees -> C if/else -> gcc -> ctypes) ----------------
class CompiledXGB:
    _counter = 0

    def __init__(self, json_path, workdir):
        CompiledXGB._counter += 1
        uid = "xgb_%d_%d" % (os.getpid(), CompiledXGB._counter)
        os.makedirs(workdir, exist_ok=True)
        with open(json_path) as fh:
            learner = json.load(fh)["learner"]
        if learner["objective"]["name"] != "binary:logistic":
            raise NotImplementedError("binary:logistic only")
        bs = float(str(learner["learner_model_param"]["base_score"]).strip("[] ").split(",")[0])
        self.base_margin = math.log(bs / (1.0 - bs))
        trees = learner["gradient_booster"]["model"]["trees"]
        self.n_trees = len(trees)
        self.n_nodes = int(sum(len(t["left_children"]) for t in trees))
        parts = ["#include <stddef.h>", "static float g_base = %s;" % self._f(self.base_margin)]
        for i, t in enumerate(trees):
            parts.append(self._emit_tree(t, i))
        body = ["float predict_margin(const float* x) {", "  float s = g_base;"]
        body += ["  s += tree_%d(x);" % i for i in range(len(trees))]
        body += ["  return s;", "}"]
        parts.append("\n".join(body))
        parts.append("int predict_label(const float* x) { return predict_margin(x) > 0.0f; }")
        parts.append("void predict_margin_batch(const float* X, int n, int d, float* out) {\n"
                     "  for (int i = 0; i < n; i++) out[i] = predict_margin(X + (size_t)i * (size_t)d);\n}")
        parts.append("void set_base(float b) { g_base = b; }")
        parts.append("float get_base(void) { return g_base; }")
        c_path = os.path.join(workdir, uid + ".c")
        so_path = os.path.join(workdir, uid + (".dll" if os.name == "nt" else ".so"))
        with open(c_path, "w") as fh:
            fh.write("\n".join(parts) + "\n")
        cc = shutil.which("gcc") or shutil.which("cc") or shutil.which("clang")
        if cc is None:
            raise RuntimeError("no C compiler (gcc/cc/clang) found")
        cmd = [cc, "-O3", "-shared", "-o", so_path, c_path]
        if os.name != "nt":
            cmd.insert(2, "-fPIC")
        subprocess.run(cmd, check=True, capture_output=True)
        self.lib = ctypes.CDLL(os.path.abspath(so_path))
        self.lib.predict_label.argtypes = [ctypes.c_void_p]
        self.lib.predict_label.restype = ctypes.c_int
        self.lib.predict_margin_batch.argtypes = [ctypes.c_void_p, ctypes.c_int, ctypes.c_int, ctypes.c_void_p]
        self.lib.predict_margin_batch.restype = None
        self.lib.set_base.argtypes = [ctypes.c_float]
        self.lib.get_base.restype = ctypes.c_float
        self.c_label = self.lib.predict_label

    @staticmethod
    def _f(v):
        return repr(float(np.float32(v))) + "f"

    def _emit_tree(self, t, idx):
        left, right = t["left_children"], t["right_children"]
        feat, cond = t["split_indices"], t["split_conditions"]
        lines = []

        def rec(n, d):
            pad = "  " * d
            if left[n] == -1:
                lines.append("%sreturn %s;" % (pad, self._f(cond[n])))
            else:
                lines.append("%sif (x[%d] < %s) {" % (pad, int(feat[n]), self._f(cond[n])))
                rec(left[n], d + 1)
                lines.append("%s} else {" % pad)
                rec(right[n], d + 1)
                lines.append("%s}" % pad)
        rec(0, 1)
        return "static inline float tree_%d(const float* x) {\n%s\n}\n" % (idx, "\n".join(lines))

    def margins(self, X):
        X = np.ascontiguousarray(X, dtype=np.float32)
        out = np.empty(len(X), dtype=np.float32)
        self.lib.predict_margin_batch(X.ctypes.data, len(X), X.shape[1], out.ctypes.data)
        return out

    def calibrate(self, booster, X, n=2000):
        import xgboost as xgb
        Xs = np.ascontiguousarray(X[:n], dtype=np.float32)
        ref = booster.predict(xgb.DMatrix(Xs), output_margin=True)
        mine = self.margins(Xs)
        off = float(np.median(ref - mine))
        if abs(off) > 1e-4:
            self.lib.set_base(self.lib.get_base() + off)
            mine = self.margins(Xs)
        return float(np.max(np.abs(ref - mine)))


class XGBEvaluator:
    """Compiled-C XGBoost when a C compiler exists, otherwise the normal XGBoost booster."""
    def __init__(self, json_path):
        import xgboost as xgb
        self.booster = xgb.Booster()
        self.booster.load_model(json_path)
        self.compiled = None
        self.mode = "XGBoost booster"
        try:
            self.compiled = CompiledXGB(json_path, os.path.join(os.path.dirname(json_path), "xgb_compiled"))
            self.mode = "compiled-C XGBoost"
        except Exception as e:
            mlog("compiled XGBoost not available (%s: %s) -> using the XGBoost booster"
                 % (type(e).__name__, str(e)[:80]))

    def verify(self, E):
        """Compare compiled output with the booster on real embeddings; drop it if they disagree."""
        if self.compiled is None or len(E) == 0:
            return
        try:
            err = self.compiled.calibrate(self.booster, E)
            if err > 1e-3:
                mlog("compiled XGBoost margin error %.2e too large -> using the XGBoost booster" % err)
                self.compiled, self.mode = None, "XGBoost booster"
        except Exception as e:
            mlog("compiled XGBoost check failed (%s) -> using the XGBoost booster" % e)
            self.compiled, self.mode = None, "XGBoost booster"

    def label_one(self, emb):                            # emb (1, D) float32 C-contiguous
        if self.compiled is not None:
            return self.compiled.c_label(emb.ctypes.data)
        return int(self.booster.inplace_predict(emb, predict_type="margin")[0] > 0)

    def labels(self, E):
        E = np.ascontiguousarray(E, dtype=np.float32)
        if self.compiled is not None:
            return (self.compiled.margins(E) > 0).astype(np.int8)
        return (self.booster.inplace_predict(E, predict_type="margin") > 0).astype(np.int8)


def make_interpreter(path):
    try:
        import tensorflow as tf
        return tf.lite.Interpreter(model_path=path)
    except Exception:
        from ai_edge_litert.interpreter import Interpreter      # newer name of the same runtime
        return Interpreter(model_path=path)


class Detector:
    """The deployed pipeline:  29x29 frame -> int8 TFLite DCNN_Lite -> 64-d embedding -> XGBoost -> 0/1."""
    def __init__(self, tflite_path, xgb_json, keras_path=None):
        self.xgb = XGBEvaluator(xgb_json)
        self.interp = self.keras_model = None
        if tflite_path and os.path.exists(tflite_path):
            try:
                self.interp = make_interpreter(tflite_path)
                self.interp.allocate_tensors()
                self.inp = self.interp.get_input_details()[0]["index"]
                self.out = self.interp.get_output_details()[0]["index"]
            except Exception as e:
                mlog("int8 TFLite could not be loaded (%s) -> float Keras extractor" % e)
                self.interp = None
        if self.interp is None:
            tf, keras, layers = lazy_tf()
            self.keras_model = keras.models.load_model(keras_path, compile=False)
        self.mode = ("int8 TFLite" if self.interp is not None else "float Keras") + " + " + self.xgb.mode

    def classify_many(self, X):
        """X (n,29,29,1) float32 -> labels (n,) int8; frame by frame like a real ECU."""
        n = len(X)
        out = np.zeros(n, dtype=np.int8)
        if self.interp is not None and self.xgb.compiled is None:
            return self.xgb.labels(self.embeddings(X))      # no C compiler: one booster call for all frames
        if self.interp is not None:
            interp, inp, outi, lab = self.interp, self.inp, self.out, self.xgb.label_one
            for i in range(n):
                interp.set_tensor(inp, X[i:i + 1])
                interp.invoke()
                out[i] = lab(np.ascontiguousarray(interp.get_tensor(outi), dtype=np.float32))
        else:
            for a in range(0, n, 256):
                emb = self.keras_model.predict(X[a:a + 256], verbose=0)
                out[a:a + 256] = self.xgb.labels(emb)
        return out

    def embeddings(self, X):
        if self.interp is not None:
            E = np.empty((len(X), int(self.interp.get_output_details()[0]["shape"][-1])), dtype=np.float32)
            for i in range(len(X)):
                self.interp.set_tensor(self.inp, X[i:i + 1])
                self.interp.invoke()
                E[i] = self.interp.get_tensor(self.out)[0]
            return E
        return self.keras_model.predict(X, verbose=0).astype(np.float32)


# ======================================================================================
# 3. TRAINING (runs in a background thread) + saved-model cache
# ======================================================================================
def config_signature():
    return dict(v=1, TRAIN_ROWS=TRAIN_ROWS, HOLDOUT_ROWS=HOLDOUT_ROWS, EPOCHS=EPOCHS,
                EMBEDDING_DIM=EMBEDDING_DIM, XGB=[XGB_N_TREES, XGB_MAX_DEPTH, XGB_LR],
                WINDOW=WINDOW, TEST_ROWS=TEST_MAX_ROWS)


def holdout_report(det, store, status_cb=None):
    """Honest test on rows that were NOT used for training (after row TRAIN_ROWS)."""
    rep = {}
    rng = np.random.default_rng(7)
    for name in ORDER:
        d = store[name]
        a, b = TRAIN_ROWS, min(d.n, TRAIN_ROWS + HOLDOUT_ROWS)
        if b - a <= WINDOW + 10:
            continue
        X, y = d.frames(a, b)
        pos, neg = np.flatnonzero(y == 1), np.flatnonzero(y == 0)
        pick = np.concatenate([rng.choice(pos, min(len(pos), 700), replace=False),
                               rng.choice(neg, min(len(neg), 700), replace=False)])
        Xf = X[pick].astype(np.float32)[..., None]
        rep[name] = metrics(y[pick], det.classify_many(Xf))
    return rep


def train_model(store):
    tf, keras, layers = lazy_tf()
    os.makedirs(MODEL_DIR, exist_ok=True)
    t_start = time.time()

    # ---- pooled training frames from all five datasets ----
    Xs, ys = [], []
    for name in ORDER:
        d = store[name]
        X, y = d.frames(0, min(d.n, TRAIN_ROWS))
        mlog("%-6s training frames=%s  attack share=%.1f%%" % (name, format(len(X), ","), 100 * y.mean()))
        Xs.append(X)
        ys.append(y)
    X, y = np.concatenate(Xs), np.concatenate(ys)
    del Xs, ys
    rng = np.random.default_rng(42)
    idx = rng.permutation(len(X))
    X, y = X[idx], y[idx]
    cut = int(len(X) * (1 - TEST_FRAC))
    Xtr, Xte, ytr, yte = X[:cut], X[cut:], y[:cut], y[cut:]
    del X, y
    gc.collect()
    mlog("pooled: train=%s  test=%s frames" % (format(len(Xtr), ","), format(len(Xte), ",")))

    def make_ds(Xu, yu, shuffle):
        ds = tf.data.Dataset.from_tensor_slices((Xu, yu.astype(np.int32)))
        if shuffle:
            ds = ds.shuffle(min(10_000, len(Xu)), reshuffle_each_iteration=True)
        ds = ds.batch(BATCH_SIZE).map(lambda a, b: (tf.expand_dims(tf.cast(a, tf.float32), -1), b),
                                      num_parallel_calls=tf.data.AUTOTUNE)
        return ds.prefetch(tf.data.AUTOTUNE)

    # ---- 1) DCNN_Lite as a classifier (skipped if a finished network was saved earlier) ----
    stage1 = os.path.join(MODEL_DIR, "stage1_extractor.keras")
    stage1_meta = os.path.join(MODEL_DIR, "stage1.json")
    extractor, epochs_run = None, 0
    if not FORCE_RETRAIN and os.path.exists(stage1) and os.path.exists(stage1_meta):
        try:
            with open(stage1_meta) as fh:
                sm = json.load(fh)
            if sm.get("config") == json.loads(json.dumps(config_signature())):
                extractor = keras.models.load_model(stage1, compile=False)
                epochs_run = sm.get("epochs_run", 0)
                mlog("neural network was already trained and saved -> skipping its training")
        except Exception as e:
            mlog("saved neural network could not be loaded (%s) -> training it again" % e)
            extractor = None
    if extractor is None:
        ds_tr, ds_te = make_ds(Xtr, ytr, True), make_ds(Xte, yte, False)
        steps = int(math.ceil(len(Xtr) / BATCH_SIZE))
        cnn = build_dcnn_lite()
        mlog("DCNN_Lite parameters: %s | %d steps/epoch | up to %d epochs" % (format(cnn.count_params(), ","), steps, EPOCHS))
        cnn.compile(optimizer=keras.optimizers.Adam(make_lr(steps, EPOCHS)),
                    loss="sparse_categorical_crossentropy", metrics=["accuracy"])
        hist = cnn.fit(ds_tr, validation_data=ds_te, epochs=EPOCHS, verbose=2,
                       callbacks=[keras.callbacks.EarlyStopping(monitor="val_loss", patience=2,
                                                                restore_best_weights=True)])
        epochs_run = len(hist.history["loss"])
        # ---- 2) 64-d feature extractor (saved at once, so later steps can never cost this training again) ----
        extractor = keras.Model(cnn.input, cnn.get_layer("feature_embedding").output,
                                name="DCNN_Lite_FeatureExtractor")
        extractor.save(stage1)
        with open(stage1_meta, "w") as fh:
            json.dump(dict(config=config_signature(), epochs_run=epochs_run), fh)
        mlog("neural network saved (%s)" % os.path.basename(stage1))
        del cnn, ds_tr, ds_te

    def embed(Xu):
        out = []
        for a in range(0, len(Xu), 20_000):
            out.append(extractor.predict(Xu[a:a + 20_000].astype(np.float32)[..., None],
                                         batch_size=BATCH_SIZE, verbose=0))
        return np.concatenate(out)
    mlog("computing training embeddings ...")
    feat_tr = embed(Xtr)

    # ---- 3) XGBoost on the embeddings ----
    mlog("training XGBoost (%d trees, depth %d) ..." % (XGB_N_TREES, XGB_MAX_DEPTH))
    import xgboost as xgb
    params = dict(objective="binary:logistic", eval_metric="logloss", max_depth=XGB_MAX_DEPTH,
                  eta=XGB_LR, subsample=0.8, colsample_bytree=0.8, seed=42,
                  nthread=os.cpu_count() or 1)
    booster = xgb.train(params, xgb.DMatrix(feat_tr, label=ytr), num_boost_round=XGB_N_TREES)
    xgb_json = os.path.join(MODEL_DIR, "xgb_model.json")
    booster.save_model(xgb_json)

    # ---- 4) int8 TFLite export (calibrated on N_CALIB training frames) ----
    tflite_path = os.path.join(MODEL_DIR, "dcnn_lite_int8.tflite")
    keras_path = os.path.join(MODEL_DIR, "dcnn_lite_extractor.keras")
    tflite_ok = True
    try:
        calib = Xtr[:N_CALIB].astype(np.float32)[..., None]

        def rep_data():
            for fr in calib:
                yield [fr[np.newaxis, ...]]
        conv = tf.lite.TFLiteConverter.from_keras_model(extractor)
        conv.optimizations = [tf.lite.Optimize.DEFAULT]
        conv.representative_dataset = rep_data
        conv.target_spec.supported_ops = [tf.lite.OpsSet.TFLITE_BUILTINS_INT8]
        conv.inference_input_type = tf.float32
        conv.inference_output_type = tf.float32
        pathlib.Path(tflite_path).write_bytes(conv.convert())
        mlog("int8 TFLite model written (%.1f KB)" % (os.path.getsize(tflite_path) / 1024.0))
    except Exception as e:
        tflite_ok = False
        mlog("int8 TFLite export failed (%s: %s) -> keeping the float Keras extractor" % (type(e).__name__, str(e)[:100]))
        if os.path.exists(tflite_path):
            os.remove(tflite_path)
    extractor.save(keras_path)

    # ---- 5) test the real deployed pipeline ----
    det = Detector(tflite_path if tflite_ok else None, xgb_json, keras_path)
    n_t = min(2000, len(Xte))
    Xt = Xte[:n_t].astype(np.float32)[..., None]
    det.xgb.verify(det.embeddings(Xt[:500]))
    m_pool = metrics(yte[:n_t], det.classify_many(Xt))
    mlog("pooled test (%d frames, deployed pipeline [%s]): recall=%.4f  precision=%.4f  FNR=%.3f%%  FPR=%.3f%%"
         % (n_t, det.mode, m_pool["recall"], m_pool["precision"], m_pool["FNR_pct"], m_pool["FPR_pct"]))
    hold = holdout_report(det, store)
    for k, v in hold.items():
        mlog("held-out %-6s recall=%.3f  FPR=%.3f%%  (frames %d, attack %d)" %
             (k, v["recall"], v["FPR_pct"], v["frames"], v["attack_frames"]))
    meta = dict(config=config_signature(), tflite_ok=tflite_ok, pooled_test=m_pool, holdout=hold,
                epochs_run=epochs_run, train_seconds=round(time.time() - t_start, 1))
    with open(os.path.join(MODEL_DIR, "meta.json"), "w") as fh:
        json.dump(meta, fh, indent=1)
    del extractor, booster, Xtr, Xte
    gc.collect()
    return det, meta


def load_cached_model():
    meta_path = os.path.join(MODEL_DIR, "meta.json")
    if FORCE_RETRAIN or not os.path.exists(meta_path):
        return None
    try:
        with open(meta_path) as fh:
            meta = json.load(fh)
        if meta.get("config") != json.loads(json.dumps(config_signature())):
            mlog("saved model was trained with other settings -> training again")
            return None
        tflite = os.path.join(MODEL_DIR, "dcnn_lite_int8.tflite") if meta.get("tflite_ok") else None
        det = Detector(tflite, os.path.join(MODEL_DIR, "xgb_model.json"),
                       os.path.join(MODEL_DIR, "dcnn_lite_extractor.keras"))
        return det, meta
    except Exception as e:
        mlog("saved model could not be loaded (%s) -> training again" % e)
        return None


class ModelService:
    """Loads the data and trains (or loads) the model in a background thread."""
    def __init__(self):
        self.ready = threading.Event()
        self.failed = None
        self.status = "starting"
        self.store = self.detector = self.meta = None
        self.thread = threading.Thread(target=self._run, daemon=True)

    def start(self):
        self.thread.start()

    def _run(self):
        try:
            if not DEFENSE_ENABLED:
                self.status = "ready"
                return
            self.status = "loading the five datasets"
            self.store = load_all_datasets()
            self.status = "checking for a saved model"
            cached = None if not DEFENSE_ENABLED else load_cached_model()
            if cached is not None:
                self.detector, self.meta = cached
                mlog("saved model loaded from %s  [%s]" % (MODEL_DIR, self.detector.mode))
            elif DEFENSE_ENABLED:
                self.status = "training the model (see [model] lines)"
                self.detector, self.meta = train_model(self.store)
                mlog("training finished in %.0f s  [%s]" % (self.meta["train_seconds"], self.detector.mode))
            self.status = "ready"
        except Exception as e:
            self.failed = "%s: %s" % (type(e).__name__, e)
            traceback.print_exc()
        finally:
            self.ready.set()


# ======================================================================================
# 4. CAN-bus gateway of each vehicle (what the model gets to see)
# ======================================================================================
def dice_key(key, salt):
    return zlib.crc32(("%s:%s" % (key, salt)).encode()) / 2**32


class CanBus:
    """Emulates the CAN bus of a vehicle with real dataset traffic.
       Attacked vehicle  -> real attack frames of its attack's dataset, from the same second.
       Other vehicles    -> real normal traffic (windows that contain no attack frame)."""
    def __init__(self, store):
        self.store = store
        self.names = list(store)

    def frame(self, veh, attack, sec):
        key = "%s@%d" % (veh, sec)
        bits = None
        if attack is not None:
            d = self.store[attack]
            if 0 <= sec < len(d.sec_ptr) - 1:
                lo, hi = d.sec_ptr[sec], d.sec_ptr[sec + 1]
                i0, i1 = np.searchsorted(d.atk_idx, lo), np.searchsorted(d.atk_idx, hi)
                if i1 > i0:                              # a window that contains an injected frame
                    r = int(d.atk_idx[i0 + int(dice_key(key, "r") * (i1 - i0))])
                    st = min(max(r - int(dice_key(key, "o") * WINDOW), 0), d.n - WINDOW)
                    bits = d.bits[st:st + WINDOW]
        if bits is None:                                 # quiet bus (or no injected frame this second)
            d = self.store[self.names[int(dice_key(key, "d") * len(self.names))]]
            pool = d.normal_starts
            st = int(pool[int(dice_key(key, "n") * len(pool))])
            bits = d.bits[st:st + WINDOW]
        return bits


# ======================================================================================
# 5. ATTACKS (same models as attack.py)
# ======================================================================================
def build_timeline_json():
    data = {}
    for name in ORDER:
        path = os.path.join(HERE, CSV_FILES[name])
        print("reading", path, flush=True)
        total, attack, t0 = {}, {}, None
        with open(path) as f:
            for line in f:
                p = line.strip().split(",")
                ts = float(p[0])
                if t0 is None:
                    t0 = ts
                s = int(ts - t0)
                total[s] = total.get(s, 0) + 1
                if p[-1] == "T":
                    attack[s] = attack.get(s, 0) + 1
        n = max(total) + 1
        data[name] = {"total": [total.get(i, 0) for i in range(n)],
                      "attack": [attack.get(i, 0) for i in range(n)]}
    with open(TIMELINE_JSON, "w") as f:
        json.dump(data, f)
    return data


class Timeline:
    def __init__(self, name, data):
        self.name = name
        self.total, self.attack = data["total"], data["attack"]
        n = len(self.total)
        self.win_of = [-1] * n
        self.windows = []
        cur = None
        for i in range(n):
            if self.attack[i] > 0:
                if cur is None:
                    cur = {"start": i, "end": i, "atk": 0, "tot": 0}
                    self.windows.append(cur)
                cur["end"] = i
                cur["atk"] += self.attack[i]
                cur["tot"] += self.total[i]
                self.win_of[i] = len(self.windows) - 1
            else:
                cur = None
        for w in self.windows:
            w["ratio"] = w["atk"] / max(1, w["tot"])
        self.starts = [w["start"] for w in self.windows]
        self.mean_ratio = sum(w["ratio"] for w in self.windows) / len(self.windows)

    def active(self, sec):
        if self.name == "REPLAY":
            return range(bisect_left(self.starts, sec - REPLAY_HOLD_S + 1), bisect_right(self.starts, sec))
        b = self.win_of[sec] if 0 <= sec < len(self.win_of) else -1
        return [b] if b >= 0 else []

    def until(self, wid):
        w = self.windows[wid]
        return w["start"] + REPLAY_HOLD_S if self.name == "REPLAY" else w["end"] + 1

    def hit_probability(self, wid):
        return min(1.0, INFECTION[self.name] * self.windows[wid]["ratio"] / self.mean_ratio)


def dice(veh_id, wid, salt):
    return zlib.crc32(("%s:%d:%s" % (veh_id, wid, salt)).encode()) / 2**32


def dice_sec(veh_id, sec, salt):
    return zlib.crc32(("%s:s%d:%s" % (veh_id, sec, salt)).encode()) / 2**32


def stale_speed(hist, lag, current):
    if not hist:
        return current
    return hist[-lag] if len(hist) >= lag else hist[0]


def fuzz_speed(veh, sec, lo=0.0):
    return lo + dice_sec(veh, sec, "spd") * (FUZZY_MAX_SPEED - lo)


def fuzz_swerve(veh, sec):
    if dice_sec(veh, sec, "lc") < FUZZY_SWERVE_PROB:
        direction = 1 if dice_sec(veh, sec, "dir") < 0.5 else -1
        try:
            traci.vehicle.changeLaneRelative(veh, direction, 2.0)
        except (traci.TraCIException, AttributeError):
            pass


def runaway_speed(current):
    return min(GEAR_MAX_SPEED, current + GEAR_ACCEL)


def gear_speed(mode, current):
    if mode == "NEUTRAL":
        v = current * GEAR_COAST_DECAY
        return 0.0 if v < 0.3 else v
    return runaway_speed(current)


def surge_speed(veh, sec):
    phase = zlib.crc32(veh.encode()) % RPM_SURGE_PERIOD_S
    v = RPM_SURGE_MEAN + RPM_SURGE_AMP * math.sin(2 * math.pi * (sec + phase) / RPM_SURGE_PERIOD_S)
    return max(0.0, v)


def rpm_speed(veh, mode, sec, current):
    if mode == "LIMITER":
        return max(RPM_LIMITER_SPEED, current - RPM_LIMITER_DECEL)
    return surge_speed(veh, sec)


def attack_speed(veh, st, sec, hist):
    typ = st["type"]
    cur = traci.vehicle.getSpeed(veh)
    if typ == "DOS":
        return st["speed0"]
    if typ == "REPLAY":
        return stale_speed(hist.get(veh), st["lag"], cur)
    if typ == "FUZZY":
        fuzz_swerve(veh, sec)
        return fuzz_speed(veh, sec)
    if typ == "GEAR":
        return gear_speed(st["mode"], cur)
    return rpm_speed(veh, st["mode"], sec, cur)


def load_timelines():
    if os.path.exists(TIMELINE_JSON):
        with open(TIMELINE_JSON) as f:
            data = json.load(f)
    else:
        print("all_attacks_timeline.json not found -> building it from the five CSV files", flush=True)
        data = build_timeline_json()
    return {name: Timeline(name, data[name]) for name in ORDER}


class Log:
    def __init__(self):
        self.f = open(LOG_FILE, "w", newline="")
        self.w = csv.writer(self.f)
        self.w.writerow(["sim_time", "event", "attack", "vehicle", "window_id", "dataset_second", "detail"])

    def add(self, t, event, attack="", veh="", wid="", sec="", detail=""):
        self.w.writerow([round(t, 1), event, attack, veh, wid, sec, detail])
        self.f.flush()


# ======================================================================================
# 6. MAIN: city + attacks + detection + mitigation
# ======================================================================================
def check_pandas():
    """Keras and XGBoost import pandas if it exists; a broken/hidden pandas crashes them."""
    try:
        import pandas
        ok = hasattr(pandas, "DataFrame") and hasattr(pandas, "Series")
        where = getattr(pandas, "__file__", None) or list(getattr(pandas, "__path__", []))
    except ImportError:
        return                                           # no pandas at all is fine
    except Exception as e:
        ok, where = False, repr(e)
    if not ok:
        print("\nCannot start: the Python package 'pandas' on this PC is broken or hidden.\n"
              "  It resolves to: %s\n"
              "  Fix:  pip install --force-reinstall pandas\n"
              "  and make sure there is no file or folder named 'pandas' (or pandas.py) next to your scripts."
              % where)
        sys.exit(1)


def check_requirements():
    if DEFENSE_ENABLED:
        check_pandas()
    problems = []
    for mod in (["numpy", "tensorflow", "xgboost"] if DEFENSE_ENABLED else ["numpy"]):
        if importlib.util.find_spec(mod) is None:
            problems.append("python package '%s' is missing" % mod)
    for name in ORDER:
        if not os.path.exists(os.path.join(HERE, CSV_FILES[name])):
            problems.append("file %s is missing in %s" % (CSV_FILES[name], HERE))
    if not os.path.exists(CFG):
        problems.append("city.sumocfg is missing in %s" % HERE)
    if problems:
        print("\nCannot start:\n  - " + "\n  - ".join(problems))
        print("\nInstall packages with:  pip install tensorflow xgboost")
        sys.exit(1)


def wait_for_model(service):
    t0, last = time.time(), 0.0
    banner("t=%d s: waiting for the model (%s) ..." % (DEPLOY_S, service.status))
    while not service.ready.wait(timeout=1.0):
        if time.time() - last >= 15:
            print("  ... still working: %s  (%d s)" % (service.status, time.time() - t0), flush=True)
            last = time.time()


def abort_no_model(service, log):
    """The model could not be loaded/trained: stop instead of running unprotected."""
    msg = str(service.failed)
    log.add(0, "MODEL_FAILED", detail=msg)
    banner("STOPPED: the model is not available, so no attack would be detected.\n"
           "  Reason: %s\n"
           "  (Fix it, or run with --no-defense to run the attacks without a model.)" % msg)
    try:
        traci.close()
    except Exception:
        pass
    sys.exit(1)


def main():
    check_requirements()
    tls = load_timelines()
    types = [n for n in ORDER if ENABLED[n]]
    log = Log()

    service = ModelService()
    service.start()                                      # training starts NOW, in the background

    cmd = ["sumo-gui" if USE_GUI else "sumo", "-c", CFG,
           "--collision.check-junctions", "true", "--collision.action", "warn",
           "--collision.stoptime", "8", "--no-step-log", "true"]
    if USE_GUI:
        cmd += ["--delay", "60", "--start"]
    traci.start(cmd)

    banner("City running normally. Model is %s in the background; it will be deployed at t=%d s"
           % ("loading/training" if DEFENSE_ENABLED else "DISABLED (--no-defense)", DEPLOY_S))

    deployed = False
    defense_on = False
    detector = bus = None
    tracked = False
    hist = {}                # natural speeds (needed by the REPLAY attack)
    victims = {}             # vehicle -> ground truth: attack currently hitting its CAN bus
    effect_on = set()        # victims whose driving is currently being overridden
    shield_until = {}        # vehicle -> sim second until which it is in safe mode
    pending = {}             # vehicle -> sim second at which the safe mode starts
    pos_hist = {}            # vehicle -> last frame decisions
    orig_color = {}
    seen_collisions = set()
    ego_done = False
    stats = {n: dict(windows=set(), episodes=0, detected=0, missed=0, mitigated=0,
                     lat=[], collisions=0) for n in ORDER}
    stats["NONE"] = dict(collisions=0)
    false_alarms = 0
    frames_classified = 0
    infer_time = 0.0

    # ---- small state helpers ----
    def sv(fn, *a):
        try:
            fn(*a)
        except traci.TraCIException:
            pass

    def refresh_color(v):
        if v in effect_on:
            st = victims[v]
            sv(traci.vehicle.setColor, v, COLORS[(st["type"], st["mode"] if st["type"] in ("GEAR", "RPM") else "")])
        elif v in shield_until:
            sv(traci.vehicle.setColor, v, SHIELD_COLOR)
        elif v in orig_color:
            sv(traci.vehicle.setColor, v, orig_color.pop(v))

    def effect_start(v):
        st = victims[v]
        if v not in orig_color:
            try:
                orig_color[v] = traci.vehicle.getColor(v)
            except traci.TraCIException:
                return
        sv(traci.vehicle.setSpeedMode, v, 0)
        if st["type"] != "REPLAY":
            sv(traci.vehicle.setLaneChangeMode, v, 0)
        effect_on.add(v)
        refresh_color(v)

    def effect_stop(v):
        sv(traci.vehicle.setSpeedMode, v, 31)
        sv(traci.vehicle.setLaneChangeMode, v, 1621)
        sv(traci.vehicle.setSpeed, v, -1)
        effect_on.discard(v)

    def engage_shield(v, sec, t):
        was_effect = v in effect_on
        if v not in orig_color:
            try:
                orig_color[v] = traci.vehicle.getColor(v)
            except traci.TraCIException:
                pass
        shield_until[v] = max(shield_until.get(v, 0), sec + SHIELD_HOLD_S)
        if was_effect:
            effect_stop(v)
            st = victims.get(v)
            if st:
                stats[st["type"]]["mitigated"] += 1
                log.add(t, "MITIGATED", st["type"], v, st["wid"], sec,
                        "attack blocked %ds after it hit; driving logic restored" % (sec - st["t_hit"]))
        refresh_color(v)

    while traci.simulation.getMinExpectedNumber() > 0:
        if DEFENSE_ENABLED and not defense_on and service.ready.is_set() and service.failed:
            abort_no_model(service, log)                 # model failed early: stop right away
        # ---- deploy the model at t = DEPLOY_S (wait if training is not finished) ----
        if not deployed and traci.simulation.getTime() + 1 >= DEPLOY_S:
            if DEFENSE_ENABLED:
                if not service.ready.is_set():
                    wait_for_model(service)
                if service.failed or service.detector is None:
                    abort_no_model(service, log)
                else:
                    detector, bus, defense_on = service.detector, CanBus(service.store), True
                    banner("MODEL DEPLOYED at t=%d s  [%s]  - attacks start now" % (DEPLOY_S, detector.mode))
                    log.add(traci.simulation.getTime(), "MODEL_DEPLOYED", detail=detector.mode)
            else:
                banner("t=%d s: attacks start (NO defence, --no-defense)" % DEPLOY_S)
            deployed = True

        traci.simulationStep()
        t = traci.simulation.getTime()
        if t >= SIM_END_S:
            break
        sec = int(t)
        ids = traci.vehicle.getIDList()
        idset = set(ids)

        # ---- natural speed history (for REPLAY) ----
        for v in ids:
            if v in effect_on:
                continue
            h = hist.get(v)
            if h is None:
                h = hist[v] = deque(maxlen=HIST_S)
            h.append(traci.vehicle.getSpeed(v))
        for v in [v for v in hist if v not in idset]:
            del hist[v]

        # ---- ego camera + highlight ----
        if "ego" in idset:
            if not tracked:
                if USE_GUI:
                    traci.gui.trackVehicle("View #0", "ego")
                    traci.gui.setZoom("View #0", 900)
                tracked = True
            traci.vehicle.highlight("ego", (255, 0, 0, 255), size=10)
        if not ego_done and "ego" in traci.simulation.getArrivedIDList():
            ego_done = True
            banner("EGO (driver car) REACHED ITS DESTINATION at t=%.0f s" % t)
            log.add(t, "EGO_ARRIVED")

        # ---- clean up vehicles that left the map ----
        for d in (victims, shield_until, pending, pos_hist, orig_color):
            for v in [v for v in d if v not in idset]:
                d.pop(v, None)
        effect_on.intersection_update(idset)

        # ---- collisions ----
        for c in traci.simulation.getCollisions():
            key = (c.collider, c.victim, sec // 20)
            if key in seen_collisions:
                continue
            seen_collisions.add(key)
            att = None
            for who in (c.collider, c.victim):
                if who in effect_on:
                    att = victims[who]["type"]
                    break
            stats[att or "NONE"]["collisions"] += 1
            log.add(t, "COLLISION", att or "", c.collider, "", sec,
                    "victim=%s edge=%s" % (c.victim, c.lane.rsplit("_", 1)[0]))

        # ---- A) safe mode starts / ends ----
        for v, due in list(pending.items()):
            if sec >= due:
                del pending[v]
                engage_shield(v, sec, t)
        for v, until in list(shield_until.items()):
            if sec >= until:
                del shield_until[v]
                refresh_color(v)
                if v in victims and sec < victims[v]["until"]:      # attack still running -> hits again
                    effect_start(v)

        # ---- B) attacks (burst timelines of the five datasets) ----
        actives = {n: (tls[n].active(sec) if (deployed and t >= START_S[n]) else []) for n in types}
        for n in types:
            for wid in actives[n]:
                if wid not in stats[n]["windows"]:
                    stats[n]["windows"].add(wid)
                    log.add(t, "WINDOW_START", n, "", wid, sec,
                            "p_hit=%.2f" % tls[n].hit_probability(wid))
        for v in list(victims):                                        # extend / expire
            st = victims[v]
            for wid in actives[st["type"]]:
                p = tls[st["type"]].hit_probability(wid) * (EGO_TARGET_BOOST if v == "ego" else 1.0)
                if dice(v, wid, st["type"]) < min(1.0, p):
                    st["until"] = max(st["until"], tls[st["type"]].until(wid))
            if sec >= st["until"]:
                if v in effect_on:
                    effect_stop(v)
                if not st["detected"]:
                    stats[st["type"]]["missed"] += 1
                    log.add(t, "MISSED", st["type"], v, st["wid"], sec, "attack ended without any alarm")
                else:
                    log.add(t, "RECOVER", st["type"], v, st["wid"], sec)
                del victims[v]
                refresh_color(v)
        for v in ids:                                                  # new hits (priority = ORDER)
            if v in victims:
                continue
            for n in types:
                boost = EGO_TARGET_BOOST if v == "ego" else 1.0
                hit = next((wid for wid in actives[n]
                            if dice(v, wid, n) < min(1.0, tls[n].hit_probability(wid) * boost)), None)
                if hit is None:
                    continue
                cur = traci.vehicle.getSpeed(v)
                st = {"type": n, "wid": hit, "until": tls[n].until(hit), "speed0": cur, "mode": "",
                      "t_hit": sec, "detected": False}
                if n == "REPLAY":
                    st["lag"] = REPLAY_LAG_MIN_S + int(dice(v, hit, "lag") * (REPLAY_LAG_MAX_S - REPLAY_LAG_MIN_S + 1))
                elif n == "GEAR":
                    st["mode"] = "NEUTRAL" if dice(v, hit, "gear") < GEAR_NEUTRAL_SHARE else "RUNAWAY"
                elif n == "RPM":
                    st["mode"] = "LIMITER" if dice(v, hit, "rpm") < RPM_LIMITER_SHARE else "SURGE"
                victims[v] = st
                stats[n]["episodes"] += 1
                blocked = shield_until.get(v, 0) > sec
                log.add(t, "VICTIM", n, v, hit, sec,
                        ("%s " % st["mode"] if st["mode"] else "") +
                        ("(already in safe mode: effect blocked)" if blocked else "(vehicle control overridden)"))
                if not blocked:
                    effect_start(v)
                break
        for v in list(effect_on):                                      # forced behaviour this second
            sv(traci.vehicle.setSpeed, v, attack_speed(v, victims[v], sec, hist))

        # ---- C) DETECTION: one CAN frame per vehicle, classified by the deployed model ----
        if defense_on and ids:
            X = np.empty((len(ids), WINDOW, 29, 1), dtype=np.float32)
            for i, v in enumerate(ids):
                X[i, :, :, 0] = bus.frame(v, victims[v]["type"] if v in victims else None, sec)
            t0 = time.perf_counter()
            labels = detector.classify_many(X)
            infer_time += time.perf_counter() - t0
            frames_classified += len(ids)
            for v, lab in zip(ids, labels):
                ph = pos_hist.get(v)
                if ph is None:
                    ph = pos_hist[v] = deque(maxlen=CONFIRM_N)
                ph.append(int(lab))
                if sum(ph) < CONFIRM_K or not lab:
                    continue
                st = victims.get(v)
                if st is not None:
                    if not st["detected"]:
                        st["detected"] = True
                        stats[st["type"]]["detected"] += 1
                        stats[st["type"]]["lat"].append(sec - st["t_hit"])
                        log.add(t, "DETECTED", st["type"], v, st["wid"], sec,
                                "attack detected %ds after it hit" % (sec - st["t_hit"]))
                else:
                    false_alarms += 1
                    log.add(t, "FALSE_ALARM", "", v, "", sec, "normal frame classified as attack")
                if MITIGATION_DELAY_S <= 0:
                    engage_shield(v, sec, t)
                elif v not in pending:
                    pending[v] = sec + MITIGATION_DELAY_S

    # ---------------- summary ----------------
    lines = ["DONE  (log: defense_log.csv)"]
    if defense_on and service.meta:
        lines.append("model: %s" % detector.mode)
    tot_ep = tot_det = 0
    for n in types:
        s = stats[n]
        tot_ep += s["episodes"]
        tot_det += s["detected"]
        lat = ("%.1fs" % (sum(s["lat"]) / len(s["lat"]))) if s["lat"] else "-"
        lines.append("  %-14s bursts %3d | vehicle hits %4d | detected %4d (%3.0f%%) | blocked %4d | missed %3d"
                     " | mean detect delay %s | crashes %d" % (
                         LABEL[n], len(s["windows"]), s["episodes"], s["detected"],
                         100.0 * s["detected"] / max(1, s["episodes"]), s["mitigated"], s["missed"], lat, s["collisions"]))
    if defense_on:
        lines.append("  total: %d hits, %d detected (%.0f%%) | false alarms on healthy vehicles: %d"
                     % (tot_ep, tot_det, 100.0 * tot_det / max(1, tot_ep), false_alarms))
        if frames_classified:
            lines.append("  model speed: %.3f ms per frame (python, this PC), %s frames classified"
                         % (1000.0 * infer_time / frames_classified, format(frames_classified, ",")))
    lines.append("  crashes between healthy vehicles: %d | driver car reached its destination: %s"
                 % (stats["NONE"]["collisions"], "YES" if ego_done else "no"))
    log.add(traci.simulation.getTime(), "END", detail=" | ".join(lines[1:3]))
    banner("\n".join(lines))
    traci.close()


if __name__ == "__main__":
    main()
